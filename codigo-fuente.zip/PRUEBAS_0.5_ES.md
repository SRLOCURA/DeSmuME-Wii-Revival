# Pruebas 0.5-test

1. Compilar en GitHub Actions.
2. Probar desde Homebrew Channel que el explorador sigue funcionando.
3. Instalar el DOL compilado como `SD:/wiiflow/plugins/desmumewii-revival.dol`.
4. Copiar uno de los INI de `dist/wiiflow/plugins/` a `SD:/wiiflow/plugins/`.
5. Recargar la caché de WiiFlow y lanzar una ROM `.nds`.
6. Confirmar que omite el menú inicial y abre la ROM directamente.
7. Abrir HOME, elegir Cerrar juego, confirmar con A.
8. Confirmar retorno al Menú de Wii; con Priiloader configurado, deberá redirigir a WiiFlow.
