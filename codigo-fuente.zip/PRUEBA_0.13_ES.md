# Prueba 0.13 — entorno de textura GX

La versión 0.12 confirmó que escalar la referencia alfa no corrige Mario Kart DS:
algunas partes de los coches quedaron blancas y el conteo 3-2-1 siguió ausente.

El código GX antiguo contenía dos limitaciones verificables:

1. El modo de textura de `POLYGON_ATTR` estaba desactivado.
2. Todos los polígonos se dibujaban con `GX_REPLACE`, incluso los que no tenían textura.

Esta prueba recupera los modos básicos de modulación/decal y usa el color de
vértice cuando el polígono no tiene textura.

Referencias visuales:
- 0.9: textura estable, conteo ausente.
- 0.10/0.11: textura convertida incorrectamente.
- 0.12: partes blancas por la prueba alfa.
