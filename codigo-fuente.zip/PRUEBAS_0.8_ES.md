# Pruebas 0.8 — perfilado de eventos de bajo impacto

Esta versión elimina las lecturas de reloj dentro de cada iteración del planificador.
El modo Completo usa contadores baratos y conserva una medición global por muestra.

## Prueba

- Frameskip 0.
- Diagnóstico Completo.
- Reiniciar medición.
- Ejecutar 20 segundos.
- Fotografiar el menú.

Repetir:
1. Yoshi's Island DS — Soft.
2. Yoshi's Island DS — GX.
3. Mario Kart DS — Soft.
4. Mario Kart DS — GX.

Registrar:
- FPS y tiempo total.
- Núcleo DS.
- Bucles.
- llamadas ARM9/ARM7.
- HStart/HBlank y líneas 2D.
- GXFIFO.
- DMA.
- Timers.
- Audio.
