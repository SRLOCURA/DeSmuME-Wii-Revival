# DeSmuME Wii Revival 0.15-test

Objetivo: validar el ciclo completo sin salir a Homebrew Channel.

1. Abrir desde Homebrew Channel.
2. Cargar Yoshi’s Island DS.
3. HOME → Cambiar juego → confirmar.
4. Verificar regreso al menú inicial de DeSmuME.
5. Cambiar Soft/GX y cargar otra ROM.
6. Repetir el cambio de juego al menos tres veces.
7. Confirmar guardados, audio, controles y ausencia de bloqueos.
8. Probar Cerrar emulador y confirmar retorno al menú de canales.

La versión 0.13 sigue siendo el DOL estable de WiiFlow durante esta prueba.
