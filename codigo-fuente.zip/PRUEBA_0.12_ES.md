# DeSmuME Wii Revival 0.12-test

Prueba controlada de compatibilidad GX:

- Base gráfica completa: 0.9 estable.
- Se descartan las optimizaciones defectuosas de 0.10/0.11.
- Único cambio: referencia de prueba alpha convertida de 5 a 8 bits.

Objetivos en Mario Kart DS con GX:

1. Confirmar que los coches recuperan colores/texturas correctos.
2. Verificar si aparece el conteo 3-2-1 antes de la salida.
3. Comprobar que no hay regresiones de rendimiento ni cuelgues.
