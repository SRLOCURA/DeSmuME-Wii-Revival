# DeSmuME Wii Revival 0.15.3-test

Resultados previos:
- 0.15.1: la segunda ROM ejecutaba audio y controles, pero no mostraba imagen.
- 0.15.2: al conservar el mutex entre ROMs, la segunda sesión se detenía antes
  de comenzar la emulación.

Conclusión:
El problema no era solo el mutex. El menú y la consola dejan el hardware GX en
un estado que no puede reutilizarse directamente por la siguiente ROM.

Esta versión crea una sesión de vídeo limpia por juego:
1. mutex nuevo;
2. reinicio de GX;
3. restauración de viewport, copia, matrices, texturas y framebuffers;
4. creación del nuevo hilo de dibujo.
