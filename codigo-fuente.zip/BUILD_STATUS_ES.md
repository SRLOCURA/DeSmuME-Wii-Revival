# Estado técnico de compilación

## Sondeo 0.7

La compilación 0.6 superó `log_console.cpp` y alcanzó `source/src/main.cpp`.
El nuevo bloqueo fue el uso restante de `MAXPATHLEN`, una constante antigua que ya no define el entorno moderno de devkitPPC/libogc.

## Corregido en 0.7

- Se añadió `<limits.h>`.
- Se usa `PATH_MAX` con respaldo de 1024 bytes cuando la plataforma no lo define.
- `NormalizeWiiFlowPath` ahora recibe el tamaño real del búfer y evita copiar más allá de sus límites.
- Las rutas predeterminadas de SD y USB usan `sizeof(filename)` en lugar de una constante antigua.
- Ya no queda ninguna referencia a `MAXPATHLEN` en `main.cpp`.

## Siguiente comprobación

Reemplazar `codigo-fuente.zip` en GitHub y ejecutar nuevamente el workflow.
El objetivo continúa siendo completar compilación y enlazado para obtener el primer `boot.dol`.
