# Estado técnico de compilación

## Segunda compilación automática completada

GitHub Actions superó el error anterior de `MAXPATHLEN` y continuó compilando hasta `source/src/FrontEnd.cpp`. El siguiente bloqueo real fue el uso de `stricmp`, una función no estándar que no está disponible en el entorno moderno de devkitPPC.

## Corregido en 0.5

- Se añadió la cabecera POSIX `<strings.h>`.
- Se reemplazó `stricmp` por `strcasecmp`.
- La comparación de extensiones `.nds` continúa sin distinguir mayúsculas y minúsculas.
- Los avisos sobre `register` y variables sin usar siguen siendo advertencias; no impiden compilar.

## Siguiente comprobación

Reemplazar `codigo-fuente.zip` en GitHub y ejecutar nuevamente el workflow. El objetivo sigue siendo llegar al enlazado completo y obtener el primer `boot.dol`.

## Todavía pendiente

- Generar un `boot.dol` enlazado completamente.
- Prueba en Wii real.
- Medición de rendimiento.
- Optimización del núcleo ARM7/ARM9.
- Plugin definitivo para WiiFlow.


### Sondeo 0.6
Se corrigió la API moderna de `devoptab_t::write_r` en `log_console.cpp`. Pendiente ejecutar GitHub Actions para localizar el siguiente bloqueo o completar el enlace.
