# Estado técnico de compilación

## Resuelto en el código

1. El arranque ya no depende de `dopmii/FileSystem.h`.
2. El enlazado ya no pide `-ldopmii` ni `-lwiikeyboard`.
3. Se retiró del Makefile la capa `gekko_utils` de USB2/mload.
4. El objetivo de salida ahora se llama `boot.dol`.
5. Se agregó un flujo reproducible con `devkitpro/devkitppc:20260503`.

## Aún por comprobar en compilación real

El código base es de 2012 y puede usar APIs retiradas o modificadas en libogc moderno. La primera ejecución de GitHub Actions servirá para obtener la lista exacta de errores restantes. Esos errores deberán corregirse uno por uno antes de generar una versión para Wii.

## No se ha realizado todavía

- Prueba en hardware real de esta rama.
- Medición de FPS.
- Optimización del núcleo ARM7/ARM9.
- Correcciones de audio o renderizado.
- Plugin definitivo de WiiFlow.
