# Estado técnico de compilación

## Primera compilación automática completada

GitHub Actions logró compilar buena parte del núcleo hasta detenerse en `source/src/filebrowser.cpp`. El primer error real fue que `MAXPATHLEN` ya no está definido por las cabeceras actuales de libogc/devkitPPC.

## Corregido en 0.4

- Se añadió `<limits.h>`.
- `MAXPATHLEN` usa `PATH_MAX` cuando está disponible.
- Se conserva un valor de respaldo de 1024 bytes para entornos que no definan `PATH_MAX`.
- Al recuperarse el tamaño del arreglo, el miembro `file_browser_st::path` vuelve a existir correctamente.

## Siguiente comprobación

Reemplazar `codigo-fuente.zip` en GitHub y ejecutar nuevamente el workflow. Es esperable que aparezcan otros errores de API antigua; se corregirán de forma iterativa hasta generar `boot.dol`.

## Todavía pendiente

- Generar un `boot.dol` enlazado completamente.
- Prueba en Wii real.
- Medición de rendimiento.
- Optimización del núcleo ARM7/ARM9.
- Plugin definitivo para WiiFlow.
