# Estado técnico de compilación

## Base confirmada

La compilación 0.7.1 completó correctamente el enlazado y generó `boot.dol` con devkitPPC moderno.
La prueba en Wii real confirmó arranque, SD, explorador, Soft, GX, Wii Remote sin Nunchuk y guardado normal.

## Cambios de 0.3-test

- Menú inicial con selección por renglones.
- Diagnóstico Off/Básico/Completo.
- Frameskip configurable antes de abrir una ROM.
- Menú de pausa al pulsar HOME.
- Pausa temporal del audio y del hilo de video al mostrar el menú.
- Reinicio de juego y salida desde el menú.
- Argumentos nuevos para WiiFlow.

## Siguiente comprobación

Compilar en GitHub Actions. Si el workflow queda verde, probar en Wii real sin reemplazar la compilación funcional anterior.
