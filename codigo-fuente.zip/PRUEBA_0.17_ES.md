# DeSmuME Wii Revival 0.17-test — audio adaptativo

La 0.16 mostró cero underruns y cero overflows. El mezclador SPU tampoco ocupa
la mayor parte del tiempo de cada cuadro.

El problema probable es temporal: el mezclador de salida avanza al 100 %,
mientras el juego y su secuenciador musical avanzan solo al 37–72 %. Los
efectos cortos pueden sonar bien, pero la música queda desalineada.

El modo Adaptativo ralentiza únicamente la reproducción de muestras de
SPU_user. El audio puede sonar más grave, pero debería ser más continuo y
acompañar mejor al juego.
