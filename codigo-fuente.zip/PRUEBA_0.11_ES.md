# DeSmuME Wii Revival 0.11-test

Prueba A/B controlada:

- **Se mantiene:** conversión optimizada de texturas lineales a RGBA8 tiled de GX.
- **Se revierte:** conversión optimizada del framebuffer GX a formato lineal.
- **Referencia 0.9 GX, Mario Kart en carrera:** 15.1 FPS, 66.2 ms, preparar 3.89 ms, render 4.80 ms.
- **Resultado fallido 0.10 GX:** 14.3 FPS, 70.0 ms, preparar 2.85 ms, render 5.75 ms y errores de colores/texturas.

Si 0.11 elimina los errores visuales, la regresión estaba en la lectura optimizada del framebuffer.
Si los errores continúan, el problema está en la conversión optimizada de texturas.
