# Prueba de DeSmuME Wii Revival 0.3-test

No reemplazar la versión que ya funciona. Instalar en una carpeta separada.

## Comprobación inicial

1. Confirmar que aparece en Homebrew Channel.
2. Cambiar entre SD/USB, Soft/GX, diagnóstico y frameskip.
3. Abrir una ROM con diagnóstico básico.
4. Jugar al menos 10 segundos.
5. Pulsar HOME y confirmar que aparece el menú de pausa.
6. Anotar FPS emulados, FPS dibujados y porcentaje de velocidad.
7. Continuar y confirmar que el juego responde.
8. Cambiar a diagnóstico completo, jugar otros 10 segundos y revisar tiempos.
9. Probar cursor, disposición de pantallas y frameskip.
10. Salir desde el menú.

## Datos útiles para reportar

- Renderizador: Soft o GX.
- Frameskip.
- FPS emulados.
- FPS dibujados.
- Velocidad estimada.
- Tiempo del núcleo DS.
- Tiempo de copia de video.
- Audio correcto, lento o entrecortado.
- Errores gráficos.
