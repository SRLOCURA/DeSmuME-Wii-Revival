# DeSmuME Wii Revival 0.18-test

Primera optimización real del núcleo.

Objetivo:
Reducir el coste de las búsquedas de memoria durante la ejecución Thumb de
ARM7. ARM7 participa en audio, entradas, temporizadores y lógica auxiliar en
prácticamente todos los juegos de Nintendo DS.

Esta versión no es una actualización completa del núcleo moderno. Es un
retroporte pequeño, medible y reversible, construido sobre 0.15.4 estable.

Pruebas principales:
- Pokémon Platinum, Soft, frameskip 0.
- Yoshi's Island DS, Soft, frameskip 0.

Comparar FPS y tiempo total con los valores ya obtenidos. También comprobar
música, efectos, guardado y cambio de ROM.
