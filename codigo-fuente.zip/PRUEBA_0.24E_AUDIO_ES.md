# DeSmuME Wii Revival 0.24E-test — filtro DSP

## Base validada

- Headroom -6 dB.
- Coseno rápido.
- FIFO estable.

## Nuevos perfiles

- Desactivado: referencia directa.
- Bloqueo DC: elimina componente continua sin recortar agudos.
- Limpio suave 16k: bloqueo DC + pasa-bajos ligero.
- Limpio fuerte 12k: limpieza mayor, con riesgo de apagar agudos.

## Prueba

Mantener:
- Soft.
- Frameskip 0.
- Headroom -6 dB.
- Coseno rápido.

Cambiar únicamente Filtro audio y escuchar la misma escena.

Reportar:
- ruido tipo bocina rota;
- claridad de agudos;
- claridad de efectos;
- volumen;
- tono;
- Núcleo DS;
- FPS;
- FIFO Under/Over.

El objetivo no es elegir automáticamente el filtro más fuerte. Debe elegirse
el perfil más suave que retire ruido sin volver apagada la música.
