# DeSmuME Wii Revival 0.24D-test — calidad frente a costo

## Resultado validado

Headroom -6 dB + Coseno LUT produjo una mejora auditiva notable, aunque con
un aumento aparente en los milisegundos del núcleo DS.

## Esta prueba

Se conservan dos variantes de coseno:

- Coseno preciso: LUT 257 + interpolación interna.
- Coseno rápido: LUT directa de 1024 entradas.

Ambas usan multiplicaciones de 32 bits. Las estadísticas de clipping también
se acumulan por bloque para reducir su propia sobrecarga.

La versión inicia con:
- Headroom -6 dB.
- Coseno rápido.

## Comparación

En la misma escena:
1. Coseno rápido durante 30 segundos.
2. Coseno preciso durante 30 segundos.
3. Lineal como referencia.

Mantener Headroom -6 dB fijo.

Observar:
- ruido de bocina rota;
- claridad de música y efectos;
- Núcleo DS;
- FPS;
- FIFO Under/Over.

La meta es conservar casi toda la mejora auditiva del coseno preciso con un
costo más cercano a la interpolación lineal.
