# Prueba de DeSmuME Wii Revival 0.4-test

## Prueba principal

1. Ejecutar desde Homebrew Channel con Soft, Frameskip 0 y Diagnostico Desactivado.
2. Abrir Yoshi's Island DS y escuchar la musica durante 20 segundos.
3. Abrir HOME, esperar 3 segundos y continuar. Repetir cinco veces.
4. Anotar cuantas veces aparece un glitch de audio.
5. Repetir con GX.

## Diagnostico

1. Llegar a la misma escena.
2. Activar Basico, elegir Reiniciar medicion, continuar 20 segundos y tomar foto.
3. Repetir con Completo.
4. Comparar contra la medicion anterior de 42.1/42.2 FPS.

No reemplazar la compilacion 0.3-test hasta confirmar estabilidad.
