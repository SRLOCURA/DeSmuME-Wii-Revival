# DeSmuME Wii Revival 0.22-test

## Microbloques

Cuando ARM9 o ARM7 queda atrasada, el planificador puede ejecutar hasta ocho
instrucciones seguidas. Se conservan el orden temporal, los ciclos, el límite
del siguiente evento, las IRQ y la reprogramación del secuenciador.

## Frameskip 0.5

Patrón: dibujar, dibujar, omitir.

Omite un tercio de los cuadros gráficos. Es más suave que frameskip 1, cuyo
patrón es dibujar, omitir.

Probar primero con frameskip 0 para aislar la mejora del núcleo. Después probar
0.5 como opción de juego.
