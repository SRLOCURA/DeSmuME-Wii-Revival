# DeSmuME Wii Revival 0.24A-test — FIFO de audio estable

Esta versión no intenta cambiar el tono ni estirar el audio. Primero corrige
la entrega de muestras entre SPU y DMA de Wii.

## Problema atacado

La salida anterior utilizaba posiciones de lectura/escritura sin un contador
explícito. Cuando ambas posiciones coincidían no podía distinguir con seguridad
una cola vacía de una llena. Además, el DMA podía copiar un bloque completo
aunque parte del contenido no hubiera sido producido todavía.

## Nueva arquitectura

- bloque DMA: 384 muestras estéreo;
- objetivo de cola: 768 muestras;
- capacidad total: 1536 muestras;
- FIFO con cantidad exacta en cola;
- productor limitado al objetivo;
- rampa a silencio si ocurre un underrun;
- estadísticas visibles en Diagnóstico Completo.

## Lo que debe evaluarse

1. Música: cantidad e intensidad de crujidos.
2. Efectos cortos: claridad y volumen.
3. Tono: debe seguir igual que en 0.21, no grave como 0.17.
4. Latencia de controles: no debe cambiar.
5. FIFO:
   - Under/Over idealmente 0/0.
   - Producción y consumo deben avanzar casi parejos.
   - La cola debe moverse alrededor de 384–768 muestras.

Esta es la base para decidir si después hacen falta perfiles de latencia,
resampleo o sincronización más avanzada.
