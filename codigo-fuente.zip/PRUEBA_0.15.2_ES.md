# DeSmuME Wii Revival 0.15.2-test

La 0.15.1 confirmó que la segunda ROM sí arrancaba:
- había sonido;
- los botones hacían avanzar el juego;
- el menú de pausa y el diagnóstico seguían funcionando.

El problema era exclusivamente la salida de vídeo. El mutex de dibujo se
destruía al cerrar la primera ROM y nunca se creaba de nuevo. Por eso el nuevo
hilo de vídeo se detenía, la pantalla conservaba el texto de inicialización y
un segundo «Cambiar juego» podía bloquear la consola.

Esta revisión mantiene el mutex de vídeo durante toda la sesión y recrea
solamente el hilo de dibujo para cada ROM.
