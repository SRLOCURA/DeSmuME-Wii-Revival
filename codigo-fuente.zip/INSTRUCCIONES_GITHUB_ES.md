# Compilar sin programar

Este paquete ya contiene el codigo y la compilacion automatica.

1. En GitHub, crea un repositorio nuevo y publico llamado `DeSmuME-Wii-Revival`.
2. En la pagina del repositorio, elige **Add file > Upload files**.
3. Descomprime este ZIP en la computadora.
4. Arrastra **todo el contenido interior** a GitHub. Deben verse en la raiz `Makefile`, `source`, `dist` y `.github`.
5. Confirma con **Commit changes**.
6. Abre la pestana **Actions** y entra en **Compilar DeSmuME Wii Revival**.
7. Si no inicia solo, pulsa **Run workflow**.
8. Cuando termine, abre la ejecucion:
   - Si sale verde, descarga `DeSmuMEWii-Revival-prueba`.
   - Si sale roja, descarga `registro-compilacion`.
9. Sube aqui el ZIP descargado. No modifiques su contenido.

No copies nada a la SD hasta que exista y revisemos un `boot.dol` compilado.
