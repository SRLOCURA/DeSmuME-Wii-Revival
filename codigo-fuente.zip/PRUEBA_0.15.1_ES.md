# DeSmuME Wii Revival 0.15.1-test

La 0.15 volvía correctamente al menú interno, pero al abrir otra ROM se detenía
en `Setting up sound...`.

Causa encontrada:
- el hilo de audio de la primera ROM seguía vivo;
- se destruían su mutex y sus búferes sin detenerlo;
- la segunda sesión intentaba reutilizar ese estado;
- además se creaba innecesariamente otro núcleo SPU.

Esta revisión corrige el ciclo de vida del audio y ordena el cierre del hilo de
vídeo. Todavía no incluye la futura mejora de calidad de sonido.
