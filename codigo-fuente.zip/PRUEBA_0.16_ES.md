# DeSmuME Wii Revival 0.16-test — diagnóstico de audio

Esta compilación no intenta mejorar todavía el sonido. Su objetivo es separar:

1. Falta real de muestras porque la emulación no alcanza el ritmo requerido.
2. Administración defectuosa del búfer circular de Wii.
3. Diferencia de frecuencia entre producción y salida.
4. Coste del mezclador SPU.

En el menú de pausa selecciona:

Diagnóstico: Audio
Reiniciar medición

Continúa jugando entre 20 y 30 segundos. Después abre HOME y fotografía todas
las líneas del bloque de audio.
