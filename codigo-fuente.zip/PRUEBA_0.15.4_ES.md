# DeSmuME Wii Revival 0.15.4-test

La 0.15.3 se detenía incluso con la primera ROM justo después de
`Starting emulation...`. La ROM sí estaba cargada; el problema fue volver a
ejecutar `GX_Init()` sobre una sesión de vídeo ya activa.

Esta revisión usa otro diseño:
- GX se inicializa una sola vez al abrir la aplicación.
- El hilo de presentación permanece vivo e inactivo en los menús.
- Al cerrar una ROM se sincroniza el hilo, se cierra NDS/audio y se vuelve al menú.
- Al abrir otra ROM solo se restauran matrices, texturas y estado GX.
