# Pruebas 0.7-test — perfilado interno

Objetivo: separar el tiempo del núcleo en tres bloques de alto nivel.

- CPU ARM9+ARM7: ejecución de instrucciones de ambos procesadores.
- Hardware: eventos programados, GPU, audio, DMA, temporizadores y periféricos.
- Planificador/otros: interrupciones, búsqueda del siguiente evento y sobrecarga restante.

## Procedimiento

1. Abrir Yoshi's Island DS desde WiiFlow con Soft.
2. Frameskip 0 y diagnóstico Completo.
3. Llegar a la misma escena usada antes.
4. Elegir Reiniciar medición.
5. Jugar 20 segundos y abrir HOME.
6. Tomar una foto.
7. Repetir con GX.

El perfil profundo se toma solo 1 de cada 16 cuadros. No usar estos datos como rendimiento final; sirven para localizar el cuello de botella.
