# DeSmuME Wii Revival 0.19-test

La 0.18 mostró una mejora pequeña repetible y ninguna regresión apreciable.
Esta revisión amplía el mismo principio a las cargas de datos de ARM7:

- bytes de 8 bits;
- medias palabras de 16 bits;
- WRAM privada y compartida.

ARM7 usa estas regiones para estado de audio, IPC, temporizadores y variables
auxiliares. La modificación no cambia valores ni ciclos emulados: solo evita
trabajo del host Wii al resolver direcciones de RAM ordinaria.

Comparar con 0.18 y 0.15.4 usando Pokémon Platinum y Yoshi's Island DS.
