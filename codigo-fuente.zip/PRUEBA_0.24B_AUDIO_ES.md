# DeSmuME Wii Revival 0.24B-test — clipping y headroom

0.24A confirmó que la FIFO de Wii no pierde ni sobrescribe muestras.
Ahora se comprueba si el sonido de «bocinas rotas» proviene del recorte duro
de la mezcla de 32 bits al convertirla a 16 bits.

Modos:
- Original.
- Headroom -3 dB: amplitud aproximada de 70.7 %.
- Headroom -6 dB: amplitud de 50 %.

No cambian tono, frecuencia ni duración.

Diagnóstico:
- Pico pre/post: amplitud máxima antes y después del perfil.
- Clip pre/post: valores fuera del rango de 16 bits.
- Valores: cantidad total de valores mono procesados.

Si el clip previo crece y el headroom reduce el clip posterior junto con la
distorsión, el origen queda confirmado. Si no, la siguiente prueba atacará
precisión del SPU, interpolación y temporización.
