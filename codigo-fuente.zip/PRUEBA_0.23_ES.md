# DeSmuME Wii Revival 0.23-test

Candidata técnica previa a la interfaz con skin de 0.24.

Base:
- 0.20: LTO y fast path Thumb ARM7.
- 0.21: caché ARM/Thumb.
- 0.22: solo frameskip 0.5.
- Microbloques retirados.

Mejoras:
- Conversión RGB15 a RGB5A3 en pares.
- Sin conversión de pantalla oculta.
- BLDCNT cacheado al cambiar el registro.
- Menos limpiezas temporales del motor OBJ.

Comparar primero con frameskip 0 frente a 0.21. Después probar 0.5.
La mejora de conversión debe aparecer principalmente en Video/Copia y tiempo
total; BLDCNT y OBJ pueden reducir ligeramente Núcleo DS.
