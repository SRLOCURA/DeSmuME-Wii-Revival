# Changelog

## 0.2-source

- Modernización inicial del almacenamiento.
- Lanzamiento directo desde argumentos.
- Selector de renderizador por argumento.
- Perfil Wii Remote sin Nunchuk.
- Hotkeys sin conflicto con botones de juego.
- Flujo de compilación CI.
- Paquete HBC preparado para cuando exista `boot.dol`.

## 0.1-source

- Primer prototipo de lanzamiento directo desde WiiFlow.

## 0.3 - prueba de compilacion automatica
- El flujo guarda `build.log` aunque la compilacion falle.
- Si compila, genera un paquete listo para Homebrew Channel.
- Paquete reorganizado para subir directamente a la raiz de un repositorio.
