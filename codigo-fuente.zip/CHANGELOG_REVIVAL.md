# Changelog

## 0.5 - comparación de extensiones portable

- Corregido el bloqueo de compilación en `FrontEnd.cpp`.
- Sustituido `stricmp` por `strcasecmp`, disponible en el entorno POSIX de devkitPPC.
- Añadida la cabecera `<strings.h>`.
- Se conserva la detección de extensiones sin distinguir mayúsculas y minúsculas.
- Pendiente ejecutar la tercera compilación para localizar el siguiente bloqueo.

## 0.4 - compatibilidad de rutas con libogc moderno

- Corregido el primer bloqueo real de compilación detectado por GitHub Actions.
- `MAXPATHLEN` ya no depende de una definición retirada: usa `PATH_MAX` de `<limits.h>` y un valor seguro de respaldo.
- Se restaura el miembro `path` del explorador de archivos y todas sus referencias.
- Pendiente ejecutar una segunda compilación para localizar el siguiente bloqueo.

## 0.2-source

- Modernización inicial del almacenamiento.
- Lanzamiento directo desde argumentos.
- Selector de renderizador por argumento.
- Perfil Wii Remote sin Nunchuk.
- Hotkeys sin conflicto con botones de juego.
- Flujo de compilación CI.
- Paquete HBC preparado para cuando exista `boot.dol`.

## 0.1-source

- Primer prototipo de lanzamiento directo desde WiiFlow.

## 0.3 - prueba de compilacion automatica
- El flujo guarda `build.log` aunque la compilacion falle.
- Si compila, genera un paquete listo para Homebrew Channel.
- Paquete reorganizado para subir directamente a la raiz de un repositorio.

## 0.6 - Compatibilidad con devoptab/newlib actual

- Se actualiza la firma de escritura de consola de `int fd` a `void *fd`, como exige el `devoptab_t` moderno.
- Se cambia el retorno de la función a `ssize_t`.
- La reproducción del registro en consola ahora pasa `NULL` como descriptor opaco.
- Esto corrige los errores de compilación de `log_console.cpp` con devkitPPC/newlib actuales.

## 0.7 - Rutas portables en main.cpp

- Corregido el bloqueo de compilación por `MAXPATHLEN` en `main.cpp`.
- Sustituido por `PATH_MAX` con un valor de respaldo compatible.
- `NormalizeWiiFlowPath` ahora recibe la capacidad del destino para copiar con límites correctos.
- Las rutas `sd:/DS/ROMS` y `usb:/DS/ROMS` usan el tamaño real del búfer.
