## 0.9-test — perfilado por etapas 3D

- Cronometra la preparación de listas/polígonos en `gfx3d_doFlush()`.
- Cronometra una sola llamada al renderizador final por cuadro.
- Registra cantidad de polígonos y vértices.
- Mantiene el muestreo espaciado para reducir el efecto del diagnóstico.

# Changelog

## 0.4-test - audio de pausa y diagnostico ligero

- Se limpia el bufer de audio al entrar y salir del menu de pausa.
- La DMA de audio se detiene al pausar y se reinicia con silencio al continuar.
- El diagnostico basico consulta el reloj solo cada 16 cuadros.
- El diagnostico completo perfila un cuadro de cada 8 en lugar de todos.
- El menu de pausa muestra el renderizador activo.
- Se agrega la opcion Reiniciar medicion para comparar escenas equivalentes.
- Se conserva una version final futura sin instrumentacion.

## 0.3-test - menús y diagnóstico

- Menú inicial ampliado con dispositivo, renderizador, diagnóstico y frameskip.
- Menú de pausa dentro del juego mediante HOME; Z+L+R en control de GameCube.
- Opciones de continuar, frameskip, pantallas, cursor, diagnóstico, reiniciar y salir.
- Diagnóstico básico de FPS emulados, FPS dibujados y velocidad estimada.
- Diagnóstico completo con tiempo del núcleo DS y copia de video.
- Las mediciones se acumulan en RAM y solo se muestran al pausar.
- Lanzamiento directo reconoce `--diagnostic=` y `--frameskip=`.
- El hilo de video y el audio se pausan mientras el menú está abierto.

## 0.5 - comparación de extensiones portable

- Corregido el bloqueo de compilación en `FrontEnd.cpp`.
- Sustituido `stricmp` por `strcasecmp`, disponible en el entorno POSIX de devkitPPC.
- Añadida la cabecera `<strings.h>`.
- Se conserva la detección de extensiones sin distinguir mayúsculas y minúsculas.
- Pendiente ejecutar la tercera compilación para localizar el siguiente bloqueo.

## 0.4 - compatibilidad de rutas con libogc moderno

- Corregido el primer bloqueo real de compilación detectado por GitHub Actions.
- `MAXPATHLEN` ya no depende de una definición retirada: usa `PATH_MAX` de `<limits.h>` y un valor seguro de respaldo.
- Se restaura el miembro `path` del explorador de archivos y todas sus referencias.
- Pendiente ejecutar una segunda compilación para localizar el siguiente bloqueo.

## 0.2-source

- Modernización inicial del almacenamiento.
- Lanzamiento directo desde argumentos.
- Selector de renderizador por argumento.
- Perfil Wii Remote sin Nunchuk.
- Hotkeys sin conflicto con botones de juego.
- Flujo de compilación CI.
- Paquete HBC preparado para cuando exista `boot.dol`.

## 0.1-source

- Primer prototipo de lanzamiento directo desde WiiFlow.

## 0.3 - prueba de compilacion automatica
- El flujo guarda `build.log` aunque la compilacion falle.
- Si compila, genera un paquete listo para Homebrew Channel.
- Paquete reorganizado para subir directamente a la raiz de un repositorio.

## 0.6 - Compatibilidad con devoptab/newlib actual

- Se actualiza la firma de escritura de consola de `int fd` a `void *fd`, como exige el `devoptab_t` moderno.
- Se cambia el retorno de la función a `ssize_t`.
- La reproducción del registro en consola ahora pasa `NULL` como descriptor opaco.
- Esto corrige los errores de compilación de `log_console.cpp` con devkitPPC/newlib actuales.

## 0.7 - Rutas portables en main.cpp

- Corregido el bloqueo de compilación por `MAXPATHLEN` en `main.cpp`.
- Sustituido por `PATH_MAX` con un valor de respaldo compatible.
- `NormalizeWiiFlowPath` ahora recibe la capacidad del destino para copiar con límites correctos.
- Las rutas `sd:/DS/ROMS` y `usb:/DS/ROMS` usan el tamaño real del búfer.

## 0.5-test
- Lanzamiento directo compatible con argumentos de WiiFlow enviados como ruta y nombre separados.
- Plantillas de plugin para Soft y GX.
- Confirmación antes de cerrar el juego.
- Cierre limpio y retorno explícito al Menú de Wii mediante libogc.
- Compatible con redirección posterior de Priiloader hacia WiiFlow.

## 0.7-test
- Añadido perfilado interno de alto nivel del núcleo.
- Separación de CPU ARM9+ARM7, hardware/eventos y planificador/otros.
- Conteo de iteraciones del bucle del núcleo.
- Muestreo profundo reducido a 1 de cada 16 cuadros.


## 0.8-test — perfilado de eventos de bajo impacto

- Se eliminó `gettime()` alrededor de cada iteración de CPU y hardware.
- El modo Completo cuenta eventos internos en lugar de cronometrar miles de bloques.
- Nuevos contadores: ARM9, ARM7, HStart, HBlank, líneas 2D, GXFIFO, DMA,
  temporizadores, audio y unidad matemática.
- El objetivo es comparar cargas de trabajo sin hundir artificialmente los FPS.
