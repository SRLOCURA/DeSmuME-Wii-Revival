# Changelog

## 0.4 - compatibilidad de rutas con libogc moderno

- Corregido el primer bloqueo real de compilación detectado por GitHub Actions.
- `MAXPATHLEN` ya no depende de una definición retirada: usa `PATH_MAX` de `<limits.h>` y un valor seguro de respaldo.
- Se restaura el miembro `path` del explorador de archivos y todas sus referencias.
- Pendiente ejecutar una segunda compilación para localizar el siguiente bloqueo.

## 0.2-source

- Modernización inicial del almacenamiento.
- Lanzamiento directo desde argumentos.
- Selector de renderizador por argumento.
- Perfil Wii Remote sin Nunchuk.
- Hotkeys sin conflicto con botones de juego.
- Flujo de compilación CI.
- Paquete HBC preparado para cuando exista `boot.dol`.

## 0.1-source

- Primer prototipo de lanzamiento directo desde WiiFlow.

## 0.3 - prueba de compilacion automatica
- El flujo guarda `build.log` aunque la compilacion falle.
- Si compila, genera un paquete listo para Homebrew Channel.
- Paquete reorganizado para subir directamente a la raiz de un repositorio.
