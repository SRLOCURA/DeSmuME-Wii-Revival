/*
    Copyright (C) 2006,2007 DeSmuME Team
    Copyright (C) 2007 Pascal Giard (evilynux)
    Copyright (C) 2009 Yoshihiro (DsonPSP)
    Copyright (C) 2012 DeSmuMEWii team

    This file is part of DeSmuMEWii

    DeSmuMEWii is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DeSmuMEWii is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DeSmuMEWii; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <fat.h>
#include <ogcsys.h>
#include <sdcard/wiisd_io.h>
#include <ogc/disc_io.h>
#include <sys/time.h>
#include <wiiuse/wpad.h>
#include <sys/dir.h>
#include <ogc/lwp_watchdog.h>
#include "MMU.h"
#include "NDSSystem.h"
#include "cflash.h"
#include "sndogc.h"
#include "ctrlssdl.h"
#include "GPU.h"
#include "render3D.h"
#include "FrontEnd.h"
#include "version.h"
#include "log_console.h"
#include "GXRender.h"
#include "rasterize.h"
#include "filebrowser.h"

#ifndef PATH_MAX
#define PATH_MAX 1024
#endif


#define NUM_FRAMES_TO_TIME 60
#define FPS_LIMITER_FRAME_PERIOD 8
#define DEFAULT_FIFO_SIZE (256*1024)
#define DIAGNOSTIC_POLL_INTERVAL 16
#define DIAGNOSTIC_FULL_SAMPLE_INTERVAL 8

NDS_header * header;

GXRModeObj *rmode = NULL;
Mtx44 perspective;
Mtx GXmodelView2D;
unsigned int *xfb[2]; // Double framebuffer [frameBuffer[fb]]
int currfb;           // Current framebuffer (0 or 1)

static u8 gp_fifo[DEFAULT_FIFO_SIZE] __attribute__((aligned(32)));
static u16 TopScreen[256*192] __attribute__((aligned(32)));
static u16 BottomScreen[256*192] __attribute__((aligned(32)));

static GXTexObj TopTex;
static GXTexObj BottomTex;
static GXTexObj CursorTex;

// TODO: Make this fancier
static u16 CursorData[16] __attribute__((aligned(32))) = {
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF,
	0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF
};
static int drawcursor = 1;
static lwp_t vidthread = LWP_THREAD_NULL;
mutex_t vidmutex = LWP_MUTEX_NULL;
static bool abort_thread = false;

static float nds_screen_size_ratio = 1.0f;
static u16 keypad;
static bool quit_game = false;
volatile bool execute = false;
static int SkipFrame = 0;
static int SkipFrameTracker = 0;
static u32 pad, wpad;
static volatile bool pause_menu_active = false;
static bool change_screen_layout = true;

// Which rendering core we are using (SoftRast or GX)
u8 current3Dcore = 1;

enum DiagnosticMode {
	DIAGNOSTIC_OFF = 0,
	DIAGNOSTIC_BASIC,
	DIAGNOSTIC_FULL
};

struct DiagnosticSnapshot {
	float emulated_fps;
	float rendered_fps;
	float speed_percent;
	float emulation_ms;
	float video_copy_ms;
	float total_frame_ms;
};

static DiagnosticMode diagnostic_mode = DIAGNOSTIC_OFF;
static DiagnosticSnapshot diagnostic_snapshot = {0, 0, 0, 0, 0, 0};
static u64 diagnostic_window_start = 0;
static u32 diagnostic_emulated_frames = 0;
static u32 diagnostic_rendered_frames = 0;
static u64 diagnostic_emulation_ms = 0;
static u64 diagnostic_video_ms = 0;
static u32 diagnostic_profile_samples = 0;
static u32 diagnostic_poll_counter = 0;
static u32 diagnostic_frame_sequence = 0;

SoundInterface_struct *SNDCoreList[] = {
	&SNDDummy,
	//&SNDFile,
	&SNDOGC,
	NULL
};

GPU3DInterface *core3DList[] = {
	&gpu3DNull,
	&gpu3Dgx,
	&gpu3DRasterize,
	NULL
};

//////////////////////////////////////////////////////////////////
////////////////////// FUNCTION PROTOTYPES ///////////////////////
//////////////////////////////////////////////////////////////////

void init();
void ShowCredits();
bool PickDevice();
static void Draw(void);
void ShowFPS();
void DSExec();
void Pause();
static void *draw_thread(void*);
void Execute();
void create_dummy_firmware();
bool CheckBios(bool);
static bool FindIOS(u32 ios);
static bool FindDirectRomArgument(int argc, char **argv, char *out_path, size_t out_size);
static bool IsUsbPath(const char *path);
static void NormalizeWiiFlowPath(char *path, size_t path_size);
static void SelectRuntimeOptionsFromArguments(int argc, char **argv);
static const char *DiagnosticModeName(DiagnosticMode mode);
static const char *ScreenLayoutName(u32 layout);
static void CycleScreenLayout(int delta);
static void CycleDiagnosticMode(int delta);
static void ResetDiagnosticWindow(bool clear_snapshot);
static void UpdateDiagnostics(u32 emulation_ms, u32 video_ms, bool rendered, bool profiled);
static void ShowPauseMenu();
static void WaitForPauseShortcutRelease();

//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

#ifdef HW_RVL
static bool FindIOS(u32 ios)
{
	s32 ret;
	u32 n;
	
	u64 *titles = NULL;
	u32 num_titles=0;
	
	ret = ES_GetNumTitles(&num_titles);
	if (ret < 0)
		return false;
	
	if(num_titles < 1) 
		return false;
	
	titles = (u64 *)memalign(32, num_titles * sizeof(u64) + 32);
	if (!titles)
		return false;
	
	ret = ES_GetTitles(titles, num_titles);
	if (ret < 0)
	{
		free(titles);
		return false;
	}
	
	for(n=0; n < num_titles; n++)
	{
		if((titles[n] & 0xFFFFFFFF)==ios) 
		{
			free(titles); 
			return true;
		}
	}
	free(titles); 
	return false;
}
#endif


static bool HasNdsExtension(const char *path)
{
	if (!path) return false;
	const char *dot = strrchr(path, '.');
	return dot && strcasecmp(dot, ".nds") == 0;
}

static void NormalizeWiiFlowPath(char *path, size_t path_size)
{
	if (!path || path_size == 0) return;

	// WiiFlow commonly labels FAT USB partitions as usb1:/, usb2:/, etc.
	// libfat mounts the active USB partition as usb:/.
	if (strncasecmp(path, "usb", 3) == 0)
	{
		char *colon = strchr(path, ':');
		if (colon)
		{
			char normalized[PATH_MAX];
			snprintf(normalized, sizeof(normalized), "usb:%s", colon + 1);
			strncpy(path, normalized, path_size - 1);
			path[path_size - 1] = '\0';
		}
	}
}

static bool IsUsbPath(const char *path)
{
	return path && strncasecmp(path, "usb:/", 5) == 0;
}

static bool FindDirectRomArgument(int argc, char **argv, char *out_path, size_t out_size)
{
	if (!argv || !out_path || out_size == 0) return false;

	for (int i = 1; i < argc; ++i)
	{
		if (!argv[i] || !HasNdsExtension(argv[i])) continue;

		strncpy(out_path, argv[i], out_size - 1);
		out_path[out_size - 1] = '\0';
		NormalizeWiiFlowPath(out_path, out_size);
		return true;
	}

	return false;
}

static const char *DiagnosticModeName(DiagnosticMode mode)
{
	switch (mode)
	{
		case DIAGNOSTIC_BASIC: return "Basico";
		case DIAGNOSTIC_FULL: return "Completo";
		default: return "Desactivado";
	}
}

static const char *ScreenLayoutName(u32 layout)
{
	switch (layout)
	{
		case SCREEN_VERT_NORMAL: return "Vertical";
		case SCREEN_VERT_SEPARATED: return "Vertical separado";
		case SCREEN_HORI_NORMAL: return "Horizontal";
		case SCREEN_VERT_STRETCH: return "Vertical estirado";
		case SCREEN_HORI_STRETCH: return "Horizontal estirado";
		case SCREEN_MAIN_NORMAL: return "Superior";
		case SCREEN_SUB_NORMAL: return "Tactil";
		case SCREEN_MAIN_STRETCH: return "Superior completa";
		case SCREEN_SUB_STRETCH: return "Tactil completa";
		case SCREEN_VERT_SEPARATED_ROT_90: return "Vertical rotado";
		default: return "Vertical";
	}
}

static void CycleScreenLayout(int delta)
{
	int value = (screen_layout < SCREEN_MAX) ? (int)screen_layout : (int)SCREEN_VERT_NORMAL;
	value += delta;
	while (value < (int)SCREEN_VERT_NORMAL) value += SCREEN_MAX;
	while (value >= (int)SCREEN_MAX) value -= SCREEN_MAX;
	screen_layout = (u32)value;
	change_screen_layout = true;
}

static void ResetDiagnosticWindow(bool clear_snapshot)
{
	diagnostic_window_start = gettime();
	diagnostic_emulated_frames = 0;
	diagnostic_rendered_frames = 0;
	diagnostic_emulation_ms = 0;
	diagnostic_video_ms = 0;
	diagnostic_profile_samples = 0;
	diagnostic_poll_counter = 0;
	diagnostic_frame_sequence = 0;

	if (clear_snapshot)
	{
		diagnostic_snapshot.emulated_fps = 0.0f;
		diagnostic_snapshot.rendered_fps = 0.0f;
		diagnostic_snapshot.speed_percent = 0.0f;
		diagnostic_snapshot.emulation_ms = 0.0f;
		diagnostic_snapshot.video_copy_ms = 0.0f;
		diagnostic_snapshot.total_frame_ms = 0.0f;
	}
}

static void CycleDiagnosticMode(int delta)
{
	int value = (int)diagnostic_mode + delta;
	while (value < (int)DIAGNOSTIC_OFF) value += 3;
	while (value > (int)DIAGNOSTIC_FULL) value -= 3;
	diagnostic_mode = (DiagnosticMode)value;
	ResetDiagnosticWindow(true);
}

static void UpdateDiagnostics(u32 emulation_ms, u32 video_ms, bool rendered, bool profiled)
{
	if (diagnostic_mode == DIAGNOSTIC_OFF)
		return;

	if (diagnostic_window_start == 0)
		ResetDiagnosticWindow(false);

	++diagnostic_emulated_frames;
	if (rendered) ++diagnostic_rendered_frames;

	if (diagnostic_mode == DIAGNOSTIC_FULL && profiled)
	{
		diagnostic_emulation_ms += emulation_ms;
		diagnostic_video_ms += video_ms;
		++diagnostic_profile_samples;
	}

	// Poll the clock only every few frames. Counting frames is cheap;
	// repeatedly querying/converting the hardware timer was the expensive part.
	if (++diagnostic_poll_counter < DIAGNOSTIC_POLL_INTERVAL)
		return;
	diagnostic_poll_counter = 0;

	const u64 now = gettime();
	const u32 elapsed_ms = ticks_to_millisecs(now - diagnostic_window_start);
	if (elapsed_ms < 1000 || diagnostic_emulated_frames == 0)
		return;

	diagnostic_snapshot.emulated_fps = (diagnostic_emulated_frames * 1000.0f) / elapsed_ms;
	diagnostic_snapshot.rendered_fps = (diagnostic_rendered_frames * 1000.0f) / elapsed_ms;
	diagnostic_snapshot.speed_percent = (diagnostic_snapshot.emulated_fps / 59.8261f) * 100.0f;
	diagnostic_snapshot.total_frame_ms = elapsed_ms / (float)diagnostic_emulated_frames;

	if (diagnostic_mode == DIAGNOSTIC_FULL && diagnostic_profile_samples > 0)
	{
		diagnostic_snapshot.emulation_ms = diagnostic_emulation_ms / (float)diagnostic_profile_samples;
		diagnostic_snapshot.video_copy_ms = diagnostic_video_ms / (float)diagnostic_profile_samples;
	}
	else
	{
		diagnostic_snapshot.emulation_ms = 0.0f;
		diagnostic_snapshot.video_copy_ms = 0.0f;
	}

	ResetDiagnosticWindow(false);
}

static void SelectRuntimeOptionsFromArguments(int argc, char **argv)
{
	// Conservative defaults for direct launch from WiiFlow.
	current3Dcore = 2;
	diagnostic_mode = DIAGNOSTIC_OFF;
	SkipFrame = 0;

	for (int i = 1; i < argc; ++i)
	{
		if (!argv[i]) continue;
		if (strcasecmp(argv[i], "--renderer=gx") == 0)
			current3Dcore = 1;
		else if (strcasecmp(argv[i], "--renderer=soft") == 0)
			current3Dcore = 2;
		else if (strcasecmp(argv[i], "--diagnostic=basic") == 0)
			diagnostic_mode = DIAGNOSTIC_BASIC;
		else if (strcasecmp(argv[i], "--diagnostic=full") == 0)
			diagnostic_mode = DIAGNOSTIC_FULL;
		else if (strcasecmp(argv[i], "--diagnostic=off") == 0)
			diagnostic_mode = DIAGNOSTIC_OFF;
		else if (strncasecmp(argv[i], "--frameskip=", 12) == 0)
		{
			int requested = atoi(argv[i] + 12);
			if (requested < 0) requested = 0;
			if (requested > 5) requested = 5;
			SkipFrame = requested;
		}
	}

	ResetDiagnosticWindow(true);
}

#ifdef __cplusplus
extern "C"
#endif

int main(int argc, char **argv)
{
	char filename[PATH_MAX];
	memset(filename, 0, sizeof(filename));
	char *rom_filename = filename;
	const bool direct_launch = FindDirectRomArgument(argc, argv, rom_filename, sizeof(filename));

	init();

	log_console_init(rmode, 0, 20, 30, rmode->fbWidth - 40, rmode->xfbHeight - 60);
	log_console_enable_video(true);

	printf("DeSmuME Wii Revival 0.4-test\n");
	printf("Initializing SD/USB storage...\n");

	// Modern libogc/libfat mounts the standard devices as sd:/ and usb:/.
	// This replaces the old dopmii and cIOS-specific USB2 startup layer.
	if (!fatInitDefault())
	{
		printf("Unable to initialize FAT storage.\n");
		printf("Check that the SD or USB device is FAT32.\n");
		sleep(5);
		return 1;
	}

	VIDEO_WaitVSync();

	bool device = false;
	if (direct_launch)
	{
		device = IsUsbPath(rom_filename);
		SelectRuntimeOptionsFromArguments(argc, argv);
	}
	else
	{
		device = PickDevice();
		if (!device)
			snprintf(rom_filename, sizeof(filename), "sd:/DS/ROMS");
		else
			snprintf(rom_filename, sizeof(filename), "usb:/DS/ROMS");
	}

	VIDEO_WaitVSync();

	if (direct_launch)
	{
		FILE *rom_test = fopen(rom_filename, "rb");
		if (!rom_test)
		{
			printf("Direct-launch ROM not found:\n%s\n", rom_filename);
			sleep(5);
			return 1;
		}
		fclose(rom_test);
		printf("Direct launch:\n%s\n", rom_filename);
		printf("Renderer: %s\n", current3Dcore == 1 ? "GX" : "Soft");
		printf("Diagnostico: %s | Frameskip: %d\n", DiagnosticModeName(diagnostic_mode), SkipFrame);
	}
	else if (FileBrowser(rom_filename) != 0)
	{
		return 0;
	}

	cflash_disk_image_file = NULL;

	printf("Initializing virtual Nintendo DS...\n");

	if (CheckBios(device))
		printf("Found external BIOS files. Will use them.\n");
	else
		printf("No external BIOS files found.\n");

	NDS_Init();
	create_dummy_firmware();

	NDS_3D_ChangeCore(current3Dcore);
	printf("Initialization successful.\n");

	enable_sound = true;

	if (enable_sound)
	{
		printf("Setting up sound...\n");
		SPU_Init(SNDCORE_OGC, 768);
	}

	printf("Placing ROM into virtual NDS...\n");
	if (NDS_LoadROM(rom_filename, cflash_disk_image_file) < 0)
	{
		printf("Error loading ROM.\n");
		sleep(5);
		return 1;
	}

	execute = true;
	ResetDiagnosticWindow(true);
	log_console_enable_video(false);

	Execute();

	fatUnmount("sd:/");
	fatUnmount("usb:/");
	return 0;
}

//////////////////////////////////////////////////////////////////
//////////////////////////// FUNCTIONS ///////////////////////////
//////////////////////////////////////////////////////////////////

void init(){
	u32 xfbHeight;
	f32 yscale;

	GXColor background = {0, 0, 0, 0xff};
	currfb = 0;

	// button initialization
	PAD_Init();
	WPAD_Init();
	VIDEO_Init();

	rmode = VIDEO_GetPreferredMode(NULL);

	switch (rmode->viTVMode >> 2)
	{
		case VI_NTSC: // 480 lines (NTSC 60hz)
			break;
		case VI_PAL: // 576 lines (PAL 50hz)
			rmode = &TVPal576IntDfScale;
			rmode->xfbHeight = 480;
			rmode->viYOrigin = (VI_MAX_HEIGHT_PAL - 480)/2;
			rmode->viHeight = 480;
			break;
		default: // 480 lines (PAL 60Hz)
			break;
	}

	
	WPAD_SetDataFormat(WPAD_CHAN_ALL, WPAD_FMT_BTNS_ACC_IR);
	WPAD_SetVRes(WPAD_CHAN_ALL,rmode->viWidth,rmode->viHeight);
	WPAD_SetIdleTimeout(200);

	VIDEO_Configure(rmode);

	xfb[0] = (u32 *)MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
	xfb[1] = (u32 *)MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));

	VIDEO_ClearFrameBuffer(rmode, xfb[0], COLOR_BLACK);
	VIDEO_ClearFrameBuffer(rmode, xfb[1], COLOR_BLACK);
	VIDEO_SetNextFramebuffer (xfb[0]);

	VIDEO_SetBlack(FALSE);

	VIDEO_Flush();
	VIDEO_WaitVSync();
	if (rmode->viTVMode & VI_NON_INTERLACE) VIDEO_WaitVSync();
	else while (VIDEO_GetNextField()) VIDEO_WaitVSync();

	memset(gp_fifo, 0, DEFAULT_FIFO_SIZE);
	GX_Init(gp_fifo, DEFAULT_FIFO_SIZE);

	GX_SetCopyClear(background, GX_MAX_Z24);
 
	// other gx setup
	GX_SetViewport(0,0,rmode->fbWidth,rmode->efbHeight,0,1);
	yscale = GX_GetYScaleFactor(rmode->efbHeight,rmode->xfbHeight);
	xfbHeight = GX_SetDispCopyYScale(yscale);
	GX_SetScissor(0,0,rmode->fbWidth,rmode->efbHeight);
	GX_SetDispCopySrc(0,0,rmode->fbWidth,rmode->efbHeight);
	GX_SetDispCopyDst(rmode->fbWidth,xfbHeight);
	GX_SetCopyFilter(rmode->aa,rmode->sample_pattern,GX_TRUE,rmode->vfilter);
	GX_SetFieldMode(rmode->field_rendering,((rmode->viHeight==2*rmode->xfbHeight)?GX_ENABLE:GX_DISABLE));

	if (rmode->aa)
		GX_SetPixelFmt(GX_PF_RGB565_Z16, GX_ZC_LINEAR);
	else
		GX_SetPixelFmt(GX_PF_RGB8_Z24, GX_ZC_LINEAR);

	GX_SetCullMode(GX_CULL_NONE);
	GX_CopyDisp(xfb[currfb],GX_TRUE);
	GX_SetDispCopyGamma(GX_GM_1_0);

	GX_SetNumChans(1);
	GX_SetNumTexGens(1);
	GX_SetTevOp(GX_TEVSTAGE0, GX_REPLACE);
	GX_SetTexCoordGen(GX_TEXCOORD0, GX_TG_MTX2x4, GX_TG_TEX0, GX_IDENTITY);

	GX_SetZMode(GX_TRUE, GX_LEQUAL, GX_TRUE);
	GX_SetBlendMode(GX_BM_BLEND, GX_BL_SRCALPHA, GX_BL_INVSRCALPHA, GX_LO_CLEAR);
	GX_SetAlphaUpdate(GX_TRUE);
	GX_SetColorUpdate(GX_TRUE);

	guOrtho(perspective,0,479,0,639,0,300);
	GX_LoadProjectionMtx(perspective, GX_ORTHOGRAPHIC);

	guMtxIdentity(GXmodelView2D);
	guMtxTransApply (GXmodelView2D, GXmodelView2D, 0.0F, 0.0F, -5.0F);
	GX_LoadPosMtxImm(GXmodelView2D,GX_PNMTX0);

	GX_SetViewport(0,0,rmode->fbWidth,rmode->efbHeight,0,1);
	GX_InvVtxCache();
	GX_ClearVtxDesc();
	GX_InvalidateTexAll();

	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XY, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST, GX_F32, 0);

	GX_SetVtxDesc(GX_VA_POS, GX_DIRECT);
	GX_SetVtxDesc(GX_VA_TEX0, GX_DIRECT);

	GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLORNULL);

	// In order to render the scene, we are taking all of the 
	// pixels and transforming them into a "texture" for the 
	// two quads that serve as our DS screens.
	GX_InitTexObj(&TopTex, TopScreen, 256, 192, GX_TF_RGB5A3, GX_CLAMP, GX_CLAMP, GX_FALSE);
	GX_InitTexObj(&BottomTex, BottomScreen, 256, 192, GX_TF_RGB5A3, GX_CLAMP, GX_CLAMP, GX_FALSE);
	GX_InitTexObj(&CursorTex, CursorData, 4, 4, GX_TF_RGB5A3, GX_CLAMP, GX_CLAMP, GX_FALSE);

	memset(TopScreen, 0, 256*192*sizeof(*TopScreen));
	memset(BottomScreen, 0, 256*192*sizeof(*BottomScreen));

	if (vidmutex == LWP_MUTEX_NULL)
		LWP_MutexInit(&vidmutex, false);

	VIDEO_SetBlack(false);
}

#define RGB15_REVERSE(col) ( 0x8000 | (((col) & 0x001F) << 10) | ((col) & 0x03E0)  | (((col) & 0x7C00) >> 10) )

static void Draw(void) {
	// convert to 4x4 textels for GX
	u16 *sTop = (u16*)&GPU_screen;
	u16 *sBottom = sTop+256*192;
	u16 *dTop = TopScreen;
	u16 *dBottom = BottomScreen;
	LWP_MutexLock(vidmutex);

	for (int y = 0; y < 48; y++) {
		for (int h = 0; h < 4; h++) {
			for (int x = 0; x < 64; x++) {
				for (int w = 0; w < 4; w++) {
					*dTop++ = RGB15_REVERSE(sTop[w]);
					*dBottom++ = RGB15_REVERSE(sBottom[w]);
				}
				dTop+=12;     // next tile
				dBottom+=12;
				sTop+=4;
				sBottom+=4;
			}
			dTop-=1020;     // next line
			dBottom-=1020;
		}
		dTop+=1008;       // next row
		dBottom+=1008;
	}

	DCFlushRange(TopScreen, 256*192*2);
	DCFlushRange(BottomScreen, 256*192*2);

	LWP_MutexUnlock(vidmutex);
	
	return;
}

static void do_screen_layout()
{
	change_screen_layout = false;

	if(screen_layout >= SCREEN_MAX)
		screen_layout = SCREEN_VERT_NORMAL;

	switch(screen_layout) 
	{
		case SCREEN_HORI_NORMAL:
			// not scaled

			topX = 	int((rmode->viWidth /2) - ((width*2) / 2));
			topY = 	int((rmode->viHeight /2) - (height / 2));
			bottomX = topX + width;
			bottomY = topY;
			scaley = scalex = 1.0;
			break;

		case SCREEN_HORI_STRETCH:
			//scaled

			scalex = float(rmode->viWidth / (width*2.0f));
			scaley = float(rmode->viHeight / height);
			topX = topY = 0;
			bottomY = 0;
			bottomX = topX + width;
			break;

		case SCREEN_VERT_NORMAL:
			// normal
			topX = 	int((rmode->viWidth / 2) - (width / 2.0f));
			topY = 	int((rmode->viHeight / 2) - ((height * 2.0f) / 2));
			bottomX = topX;
			bottomY = topY+height;
			scaley = scalex = 1.0;
			break;

        case SCREEN_VERT_SEPARATED:
			// normal
			topX =     int((rmode->viWidth / 2) - (width / 2.0f));
			topY =     int((rmode->viHeight / 2) - ((height * 2.0f) / 2) - 24);
			bottomX = topX;
			bottomY = topY+height+48;
			scaley = scalex = 1.0;
			break;

		case SCREEN_VERT_STRETCH:
			// stretched
			topX = topY = 0;
			bottomX = 0;
			scalex = float(rmode->viWidth / (width));
			scaley = float(rmode->viHeight / (height*2));
			bottomY = height;
			break;

		case SCREEN_MAIN_STRETCH:
		case SCREEN_SUB_STRETCH:
			topX = topY = 0;
			bottomX = bottomY = 0;
			scalex = float(rmode->viWidth / (width));
			scaley = float(rmode->viHeight / (height));
			break;

		case SCREEN_MAIN_NORMAL: 
		case SCREEN_SUB_NORMAL:
			topX = bottomX = int((rmode->viWidth /2) - (width / 2));
			topY = bottomY = int((rmode->viHeight /2) - (height / 2));
			scaley = scalex = 1.0;
			break;

		case SCREEN_VERT_SEPARATED_ROT_90:
			topX =    int((rmode->viWidth / 2) - (width / 2.0f));
			topY =    int((rmode->viHeight / 2) - ((height * 2.0f) / 2) - 24);
			bottomX = topX;
			bottomY = topY+height+48;
			scaley = scalex = 1.0;
			break;
	}
};

static void *draw_thread(void*)
{
	while(1)
	{
		if (abort_thread)
			break;

		if (pause_menu_active)
		{
			VIDEO_WaitVSync();
			continue;
		}

		if(change_screen_layout)	// call it only when necessary.
			do_screen_layout();
		
		LWP_MutexLock(vidmutex);
		
		// Transform for scaling and rotate

		Mtx m, m1, m2, mv;

		guMtxIdentity (m1);
		guMtxScaleApply(m1, m1, scalex, scaley, 1.0f);
		
		guVector axis =(guVector){0, 0, 1};
		guMtxRotAxisDeg (m2, &axis, rotate_angle);
		guMtxConcat(m2, m1, m);

		guMtxTransApply(m, m, 0, 0, 0);
		guMtxConcat (GXmodelView2D, m, mv);

		GX_LoadPosMtxImm (mv, GX_PNMTX0);

		// TOP SCREEN
		if ((screen_layout != SCREEN_SUB_NORMAL) && (screen_layout != SCREEN_SUB_STRETCH))
		{
			GX_LoadTexObj(&TopTex, GX_TEXMAP0);
			GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
				GX_Position2f32(topX, topY);
				GX_TexCoord2f32(0, 0);
				GX_Position2f32(topX, topY+height);
				GX_TexCoord2f32(0, 1);
				GX_Position2f32(topX+width, topY+height);
				GX_TexCoord2f32(1, 1);
				GX_Position2f32(topX+width, topY);
				GX_TexCoord2f32(1, 0);
			GX_End();
		}
		// BOTTOM SCREEN
		if (screen_layout != SCREEN_MAIN_NORMAL && (screen_layout != SCREEN_MAIN_STRETCH))
		{
 
			GX_LoadTexObj(&BottomTex, GX_TEXMAP0);
			GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
				GX_Position2f32(bottomX, bottomY);
				GX_TexCoord2f32(0, 0);
				GX_Position2f32(bottomX, bottomY+height);
				GX_TexCoord2f32(0, 1);
				GX_Position2f32(bottomX+width, bottomY+height);
				GX_TexCoord2f32(1, 1);
				GX_Position2f32(bottomX+width, bottomY);
				GX_TexCoord2f32(1, 0);
			GX_End();

			// CURSOR
			if (drawcursor)
			{
				GX_LoadTexObj(&CursorTex, GX_TEXMAP0);
				GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
					GX_Position2f32(bottomX+mouse.x-5, bottomY+mouse.y-5);
					GX_TexCoord2f32(0, 0);
					GX_Position2f32(bottomX+mouse.x-5, bottomY+mouse.y+5);
					GX_TexCoord2f32(0, 1);
					GX_Position2f32(bottomX+mouse.x+5, bottomY+mouse.y+5);
					GX_TexCoord2f32(1, 1);
					GX_Position2f32(bottomX+mouse.x+5, bottomY+mouse.y-5);
					GX_TexCoord2f32(1, 0);
				GX_End();
			}
		}

		GX_DrawDone();

		currfb ^= 1;

		GX_CopyDisp(xfb[currfb],GX_TRUE);
		VIDEO_SetNextFramebuffer(xfb[currfb]);
		VIDEO_Flush();

		LWP_MutexUnlock(vidmutex);

		VIDEO_WaitVSync();
	}

	return NULL;
}

void Execute() {
	if(vidthread == LWP_THREAD_NULL)
		LWP_CreateThread(&vidthread, draw_thread, NULL, NULL, 0, 67);

	while(!quit_game){
		 
		if(SkipFrameTracker) NDS_SkipNextFrame(); 
	
		DSExec();

		SkipFrameTracker++;
		
		if(SkipFrameTracker > SkipFrame) SkipFrameTracker = 0;
		
	}

	abort_thread = true;
	LWP_MutexDestroy(vidmutex);
	vidmutex = LWP_MUTEX_NULL;
	LWP_JoinThread(vidthread, NULL);
	vidthread = LWP_THREAD_NULL;

	NDS_DeInit();

	GX_AbortFrame();
	GX_Flush();

	VIDEO_Flush();
	VIDEO_WaitVSync();
	VIDEO_SetBlack(true);

	return;
}

void ShowFPS() {
	u32 fps_timing = 0;
	u32 fps_frame_counter = 0;
	u32 fps_previous_time = 0;
	u32 fps_temp_time;
	float fps;

	fps_frame_counter += 1;
	fps_temp_time = ticks_to_millisecs(gettime());
	fps_timing += fps_temp_time - fps_previous_time;
	fps_previous_time = fps_temp_time;

	if ( fps_frame_counter == NUM_FRAMES_TO_TIME) {
		fps = (float)fps_timing;
		fps /= NUM_FRAMES_TO_TIME * 1000.f;
		fps = 1.0f / fps;
		fps_frame_counter = 0;
		fps_timing = 0;
		
	}
}

void DSExec(){
	PAD_ScanPads();
	WPAD_ScanPads();

	wpad = WPAD_ButtonsDown(WPAD_CHAN_0);
	pad = PAD_ButtonsDown(0);

	const u32 wpad_held = WPAD_ButtonsHeld(WPAD_CHAN_0);
	const u32 pad_held = PAD_ButtonsHeld(0);
	const bool pause_requested =
		(wpad & WPAD_BUTTON_HOME) ||
		(wpad & WPAD_CLASSIC_BUTTON_HOME) ||
		((pad_held & PAD_TRIGGER_Z) && (pad_held & PAD_TRIGGER_R) && (pad_held & PAD_TRIGGER_L));

	if (pause_requested)
	{
		ShowPauseMenu();
		return;
	}

	process_ctrls_event(&keypad, nds_screen_size_ratio);

	if(mouse.down)
		NDS_setTouchPos(mouse.x, mouse.y);

	if(mouse.click)
	{
		NDS_releaseTouch();
		mouse.click = FALSE;
	}

	update_keypad(keypad);

	// Emulator hotkeys no longer consume normal gameplay buttons.
	// Wii Remote: hold A and press D-pad.
	// Classic: hold ZL and press D-pad.
	// GameCube: hold Z and press D-pad.
	const bool wiimote_hotkey = (wpad_held & WPAD_BUTTON_A) != 0;
	const bool classic_hotkey = (wpad_held & WPAD_CLASSIC_BUTTON_ZL) != 0;
	const bool gamecube_hotkey = (pad_held & PAD_TRIGGER_Z) != 0;

	if ((wiimote_hotkey && (wpad & WPAD_BUTTON_UP)) ||
		(classic_hotkey && (wpad & WPAD_CLASSIC_BUTTON_UP)) ||
		(gamecube_hotkey && (pad & PAD_BUTTON_UP)))
	{
		CycleScreenLayout(1);
	}

	if ((wiimote_hotkey && (wpad & WPAD_BUTTON_DOWN)) ||
		(classic_hotkey && (wpad & WPAD_CLASSIC_BUTTON_DOWN)) ||
		(gamecube_hotkey && (pad & PAD_BUTTON_DOWN)))
	{
		drawcursor ^= 1;
	}

	if ((wiimote_hotkey && (wpad & WPAD_BUTTON_RIGHT)) ||
		(classic_hotkey && (wpad & WPAD_CLASSIC_BUTTON_RIGHT)) ||
		(gamecube_hotkey && (pad & PAD_BUTTON_RIGHT)))
	{
		if (SkipFrame < 5) ++SkipFrame;
		ResetDiagnosticWindow(true);
	}

	if ((wiimote_hotkey && (wpad & WPAD_BUTTON_LEFT)) ||
		(classic_hotkey && (wpad & WPAD_CLASSIC_BUTTON_LEFT)) ||
		(gamecube_hotkey && (pad & PAD_BUTTON_LEFT)))
	{
		if (SkipFrame > 0) --SkipFrame;
		ResetDiagnosticWindow(true);
	}

	u32 emulation_ms = 0;
	u32 video_ms = 0;
	u64 timing_start = 0;
	const bool profile_this_frame =
		diagnostic_mode == DIAGNOSTIC_FULL &&
		((diagnostic_frame_sequence++ % DIAGNOSTIC_FULL_SAMPLE_INTERVAL) == 0);

	if (profile_this_frame)
		timing_start = gettime();

	NDS_exec<TRUE>(0);

	if (profile_this_frame)
	{
		emulation_ms = ticks_to_millisecs(gettime() - timing_start);
		timing_start = gettime();
	}

	const bool rendered = !SkipFrameTracker;
	if (rendered) Draw();

	if (profile_this_frame)
		video_ms = ticks_to_millisecs(gettime() - timing_start);

	UpdateDiagnostics(emulation_ms, video_ms, rendered, profile_this_frame);
}

static void WaitForPauseShortcutRelease()
{
	while (true)
	{
		PAD_ScanPads();
		WPAD_ScanPads();
		const u32 wh = WPAD_ButtonsHeld(WPAD_CHAN_0);
		const u32 ph = PAD_ButtonsHeld(0);
		const bool home_held = (wh & WPAD_BUTTON_HOME) || (wh & WPAD_CLASSIC_BUTTON_HOME);
		const bool gc_combo_held = (ph & PAD_TRIGGER_Z) && (ph & PAD_TRIGGER_R) && (ph & PAD_TRIGGER_L);
		if (!home_held && !gc_combo_held) break;
		VIDEO_WaitVSync();
	}
}

static void PrintPauseMenu(int selection)
{
	printf("\x1b[2J");
	printf("\x1b[2;2H");
	printf("DeSmuME Wii Revival 0.4 - PAUSA\n\n");

	printf("Renderizador actual: %s\n\n", current3Dcore == 1 ? "GX" : "Soft");
	printf("%c Continuar\n", selection == 0 ? '>' : ' ');
	printf("%c Frameskip: %d\n", selection == 1 ? '>' : ' ', SkipFrame);
	printf("%c Pantallas: %s\n", selection == 2 ? '>' : ' ', ScreenLayoutName(screen_layout));
	printf("%c Cursor tactil: %s\n", selection == 3 ? '>' : ' ', drawcursor ? "Visible" : "Oculto");
	printf("%c Diagnostico: %s\n", selection == 4 ? '>' : ' ', DiagnosticModeName(diagnostic_mode));
	printf("%c Reiniciar medicion\n", selection == 5 ? '>' : ' ');
	printf("%c Reiniciar juego\n", selection == 6 ? '>' : ' ');
	printf("%c Salir del emulador\n", selection == 7 ? '>' : ' ');

	printf("\n");
	if (diagnostic_mode == DIAGNOSTIC_OFF)
	{
		printf("Diagnostico desactivado.\n");
	}
	else if (diagnostic_snapshot.emulated_fps <= 0.0f)
	{
		printf("Midiendo... vuelve a este menu en unos segundos.\n");
	}
	else
	{
		printf("FPS emulados: %.1f | Dibujados: %.1f\n",
			diagnostic_snapshot.emulated_fps, diagnostic_snapshot.rendered_fps);
		printf("Velocidad estimada: %.1f%% | Total: %.1f ms\n",
			diagnostic_snapshot.speed_percent, diagnostic_snapshot.total_frame_ms);
		if (diagnostic_mode == DIAGNOSTIC_FULL)
		{
			printf("Nucleo DS: %.1f ms | Copia video: %.1f ms\n",
				diagnostic_snapshot.emulation_ms, diagnostic_snapshot.video_copy_ms);
		}
	}

	printf("\nCruceta: mover/cambiar | A: aceptar\n");
	printf("B o HOME: continuar\n");
	VIDEO_WaitVSync();
}

static void ShowPauseMenu()
{
	pause_menu_active = true;
	SPU_Pause(1);
	SPU_ClearOutputBuffer();
	update_keypad(0);
	NDS_releaseTouch();

	// Wait until the rendering thread has finished its current GX section.
	LWP_MutexLock(vidmutex);
	LWP_MutexUnlock(vidmutex);

	log_console_enable_video(true);
	WaitForPauseShortcutRelease();

	int selection = 0;
	bool close_menu = false;
	PrintPauseMenu(selection);

	while (!close_menu)
	{
		PAD_ScanPads();
		WPAD_ScanPads();

		if (GetInput(UP, UP, UP))
		{
			selection = (selection + 7) % 8;
			PrintPauseMenu(selection);
		}
		else if (GetInput(DOWN, DOWN, DOWN))
		{
			selection = (selection + 1) % 8;
			PrintPauseMenu(selection);
		}
		else if (GetInput(LEFT, LEFT, LEFT) || GetInput(RIGHT, RIGHT, RIGHT))
		{
			const int direction = GetInput(LEFT, LEFT, LEFT) ? -1 : 1;
			switch (selection)
			{
				case 1:
					SkipFrame += direction;
					if (SkipFrame < 0) SkipFrame = 5;
					if (SkipFrame > 5) SkipFrame = 0;
					ResetDiagnosticWindow(true);
					break;
				case 2:
					CycleScreenLayout(direction);
					break;
				case 3:
					drawcursor ^= 1;
					break;
				case 4:
					CycleDiagnosticMode(direction);
					break;
			}
			PrintPauseMenu(selection);
		}
		else if (GetInput(A, A, A))
		{
			switch (selection)
			{
				case 0:
					close_menu = true;
					break;
				case 1:
					SkipFrame = (SkipFrame + 1) % 6;
					ResetDiagnosticWindow(true);
					break;
				case 2:
					CycleScreenLayout(1);
					break;
				case 3:
					drawcursor ^= 1;
					break;
				case 4:
					CycleDiagnosticMode(1);
					break;
				case 5:
					ResetDiagnosticWindow(true);
					break;
				case 6:
					NDS_Reset();
					ResetDiagnosticWindow(true);
					close_menu = true;
					break;
				case 7:
					quit_game = true;
					close_menu = true;
					break;
			}
			if (!close_menu) PrintPauseMenu(selection);
		}
		else
		{
			const u32 wd = WPAD_ButtonsDown(WPAD_CHAN_0);
			const u32 ph = PAD_ButtonsHeld(0);
			const bool home = (wd & WPAD_BUTTON_HOME) || (wd & WPAD_CLASSIC_BUTTON_HOME);
			const bool gc_home = (ph & PAD_TRIGGER_Z) && (ph & PAD_TRIGGER_R) && (ph & PAD_TRIGGER_L);
			if (GetInput(B, B, B) || home || gc_home)
				close_menu = true;
		}

		VIDEO_WaitVSync();
	}

	printf("\x1b[2J");
	log_console_enable_video(false);
	pause_menu_active = false;
	SPU_ClearOutputBuffer();
	VIDEO_WaitVSync();
	SPU_Pause(0);
	ResetDiagnosticWindow(false);
}

void Pause(){

	for(;;){
		WPAD_ScanPads();
		if(WPAD_ButtonsDown(WPAD_CHAN_0)&WPAD_BUTTON_A)
			break;
	}

}

bool PickDevice(){
	bool device = false;
	bool useGX = false;
	int selection = 0;
	current3Dcore = 2;
	diagnostic_mode = DIAGNOSTIC_OFF;
	SkipFrame = 0;

	while(true){
		PAD_ScanPads();
		WPAD_ScanPads();

		printf("\x1b[2J");
		printf("\x1b[2;2H");
		printf("DeSmuME Wii Revival 0.4-test\n\n");
		printf("%c Dispositivo: %s\n", selection == 0 ? '>' : ' ', device ? "USB" : "SD");
		printf("%c Renderizador: %s\n", selection == 1 ? '>' : ' ', useGX ? "GX" : "Soft");
		printf("%c Diagnostico: %s\n", selection == 2 ? '>' : ' ', DiagnosticModeName(diagnostic_mode));
		printf("%c Frameskip: %d\n", selection == 3 ? '>' : ' ', SkipFrame);
		printf("%c Explorar juegos\n", selection == 4 ? '>' : ' ');
		printf("\nCruceta: mover/cambiar | A: aceptar\n");
		printf("PLUS: iniciar | B: creditos\n");

		if(GetInput(UP, UP, UP))
			selection = (selection + 4) % 5;
		else if(GetInput(DOWN, DOWN, DOWN))
			selection = (selection + 1) % 5;
		else if(GetInput(LEFT, LEFT, LEFT) || GetInput(RIGHT, RIGHT, RIGHT))
		{
			const int direction = GetInput(LEFT, LEFT, LEFT) ? -1 : 1;
			switch(selection)
			{
				case 0: device = !device; break;
				case 1: useGX = !useGX; break;
				case 2: CycleDiagnosticMode(direction); break;
				case 3:
					SkipFrame += direction;
					if (SkipFrame < 0) SkipFrame = 5;
					if (SkipFrame > 5) SkipFrame = 0;
					break;
			}
		}
		else if(GetInput(A, A, A))
		{
			if (selection == 4)
				break;
			switch(selection)
			{
				case 0: device = !device; break;
				case 1: useGX = !useGX; break;
				case 2: CycleDiagnosticMode(1); break;
				case 3: SkipFrame = (SkipFrame + 1) % 6; break;
			}
		}
		else if(GetInput(PLUS, START, PLUS))
			break;
		else if(GetInput(B, B, B))
			ShowCredits();

		VIDEO_WaitVSync();
	}

	current3Dcore = useGX ? 1 : 2;
	ResetDiagnosticWindow(true);
	return device;
}

void ShowCredits() {

	printf("\x1b[2J");
	printf("\x1b[2;0H");
	
	printf("DeSmuME Wii\n\n");
	printf("http://code.google.com/p/desmumewii\n\n");
	printf("Written By:\n\n");
	printf("Arikado - http://arikadosblog.blogspot.com\n");
	printf("scanff\n");
	printf("DCN\n");	
	printf("firnis\n");
	printf("baby.lueshi\n");
	printf("With contributions from Cyan\n\n");

	printf("Press A to return to the menu.");
	
	while(true){ 
	    PAD_ScanPads();
		WPAD_ScanPads();
		if(GetInput(A, A, A))
		    break;
	}

}

//needed for some games
void create_dummy_firmware(){
	// Create the dummy firmware
	NDS_fw_config_data dummy;
	
	NDS_FillDefaultFirmwareConfigData(&dummy);

	NDS_CreateDummyFirmware( &dummy);
}

/*
	As we don't have a menu right now this function is used to see if the user
	has external bios files.  If they do we mark them to be used
*/
bool CheckBios(bool device){
	char path[256] = {0};

	if (!device) strcat(path,"sd:/DS/BIOS/");
	else strcat(path,"usb:/DS/BIOS/");

	FILE* biosfile = 0;

	// Check arm7 bios
	sprintf(CommonSettings.ARM7BIOS,"%sbiosnds7.rom",path);

	biosfile = fopen(CommonSettings.ARM7BIOS,"rb");
	if (!biosfile){
		printf("No ARM7 BIOS\n");
		memset(CommonSettings.ARM7BIOS,0,256);
		return false;		
	}

	fclose(biosfile);
	biosfile = 0;

	// Check arm9 bios
	sprintf(CommonSettings.ARM9BIOS,"%sbiosnds9.rom",path);

	biosfile = fopen(CommonSettings.ARM9BIOS,"rb");
	if (!biosfile){
		printf("No ARM9 BIOS\n");
		memset(CommonSettings.ARM9BIOS,0,256);
		return false;		
	}

	fclose(biosfile);
	biosfile = 0;

	CommonSettings.UseExtBIOS = true;

	return true;
}
