/*  Copyright 2005-2006 Theo Berkau
    Copyright (C) 2012 DeSmuMEWii team

    This file is part of DeSmuMEWii

    DeSmuMEWii is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DeSmuMEWii is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/
#ifndef SNDOGC_H
#define SNDOGC_H

#include <gctypes.h>

#define SNDCORE_OGC 3

struct SNDOGCStats
{
	u32 queued_samples;
	u32 target_samples;
	u32 capacity_samples;
	u32 minimum_samples;
	u32 maximum_samples;
	u32 underruns;
	u32 overflows;
	u32 dma_blocks;
	u32 produced_samples;
	u32 consumed_samples;
};

extern SoundInterface_struct SNDOGC;

void SNDOGCGetStats(SNDOGCStats *stats);
void SNDOGCResetStats();

#endif
