/*  Copyright 2005-2006 Theo Berkau
    Copyright (C) 2012 DeSmuMEWii team

    This file is part of DeSmuMEWii

    DeSmuMEWii is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DeSmuMEWii is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DeSmuMEWii; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#ifndef SNDOGC_H
#define SNDOGC_H

#define SNDCORE_OGC 3

struct SNDOGCDiagnosticSnapshot
{
	u64 produced_samples;
	u64 requested_output_samples;
	u64 real_output_samples;
	u64 missing_samples;
	u64 overflow_samples;
	u64 mix_ticks_total;
	u64 mix_ticks_max;
	u32 update_calls;
	u32 dma_callbacks;
	u32 audio_thread_loops;
	u32 underrun_events;
	u32 overflow_events;
	u32 zero_space_calls;
	u32 space_calls;
	u32 mix_timing_samples;
	u32 current_fill_samples;
	u32 min_fill_samples;
	u32 max_fill_samples;
	u32 capacity_samples;
	u32 min_free_samples;
	u32 max_free_samples;
};

extern SoundInterface_struct SNDOGC;
void SNDOGCResetDiagnostics();
void SNDOGCGetDiagnostics(SNDOGCDiagnosticSnapshot *snapshot);
#endif
