/*  Copyright 2005-2006 Theo Berkau
    Copyright (C) 2012 DeSmuMEWii team

    This file is part of DeSmuMEWii

    DeSmuMEWii is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DeSmuMEWii is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

#include <gccore.h>
#include <gctypes.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#include "types.h"
#include "SPU.h"
#include "sndogc.h"
#include "debug.h"

#include <asndlib.h>

int SNDOGCInit(int buffersize);
void SNDOGCDeInit();
void SNDOGCUpdateAudio(s16 *buffer, u32 num_samples);
u32 SNDOGCGetAudioSpace();
void SNDOGCMuteAudio();
void SNDOGCUnMuteAudio();
void SNDOGCSetVolume(int volume);
void SNDOGCClearBuffer();

SoundInterface_struct SNDOGC = {
	SNDCORE_OGC,
	"OGC Sound Interface - Stable FIFO",
	SNDOGCInit,
	SNDOGCDeInit,
	SNDOGCUpdateAudio,
	SNDOGCGetAudioSpace,
	SNDOGCMuteAudio,
	SNDOGCUnMuteAudio,
	SNDOGCSetVolume,
	SNDOGCClearBuffer
};

static const u32 BYTES_PER_STEREO_SAMPLE = sizeof(s16) * 2;
static const u32 FIFO_BLOCK_COUNT = 4;
static const u32 FIFO_TARGET_BLOCKS = 2;
static const u32 UNDERFLOW_FADE_SAMPLES = 32;

static u8 *dma_buffers[2] = { NULL, NULL };
static u8 *audio_fifo = NULL;

static volatile u8 dma_buffer_index = 0;
static u32 dma_block_bytes = 0;
static u32 fifo_capacity_bytes = 0;
static u32 fifo_target_bytes = 0;
static u32 fifo_read_pos = 0;
static u32 fifo_write_pos = 0;
static u32 fifo_queued_bytes = 0;

static lwpq_t audioqueue = LWP_TQUEUE_NULL;
static lwp_t audiothread = LWP_THREAD_NULL;
static mutex_t audiomutex = LWP_MUTEX_NULL;
static volatile bool audio_thread_abort = false;
static bool asnd_initialized = false;
static int sndogcvolume = 100;

static u32 stat_minimum_bytes = 0xFFFFFFFFu;
static u32 stat_maximum_bytes = 0;
static u32 stat_underruns = 0;
static u32 stat_overflows = 0;
static u32 stat_dma_blocks = 0;
static u32 stat_produced_samples = 0;
static u32 stat_consumed_samples = 0;

static FORCEINLINE u32 MinimumU32(const u32 a, const u32 b)
{
	return (a < b) ? a : b;
}

static void ResetStatisticsUnlocked()
{
	stat_minimum_bytes = 0xFFFFFFFFu;
	stat_maximum_bytes = 0;
	stat_underruns = 0;
	stat_overflows = 0;
	stat_dma_blocks = 0;
	stat_produced_samples = 0;
	stat_consumed_samples = 0;
}

static void RecordQueueDepthUnlocked()
{
	if (fifo_queued_bytes < stat_minimum_bytes)
		stat_minimum_bytes = fifo_queued_bytes;
	if (fifo_queued_bytes > stat_maximum_bytes)
		stat_maximum_bytes = fifo_queued_bytes;
}

static void CopyIntoFifoUnlocked(const u8 *source, u32 bytes)
{
	if (bytes == 0)
		return;

	const u32 first = MinimumU32(bytes, fifo_capacity_bytes - fifo_write_pos);
	memcpy(audio_fifo + fifo_write_pos, source, first);

	const u32 second = bytes - first;
	if (second)
		memcpy(audio_fifo, source + first, second);

	fifo_write_pos = (fifo_write_pos + bytes) % fifo_capacity_bytes;
	fifo_queued_bytes += bytes;
}

static void CopyFromFifoUnlocked(u8 *destination, u32 bytes)
{
	if (bytes == 0)
		return;

	const u32 first = MinimumU32(bytes, fifo_capacity_bytes - fifo_read_pos);
	memcpy(destination, audio_fifo + fifo_read_pos, first);

	const u32 second = bytes - first;
	if (second)
		memcpy(destination + first, audio_fifo, second);

	fifo_read_pos = (fifo_read_pos + bytes) % fifo_capacity_bytes;
	fifo_queued_bytes -= bytes;
}

static void FadeMissingAudio(u8 *destination, const u32 valid_bytes, const u32 total_bytes)
{
	if (valid_bytes >= total_bytes)
		return;

	u32 missing_bytes = total_bytes - valid_bytes;
	memset(destination + valid_bytes, 0, missing_bytes);

	if (valid_bytes < BYTES_PER_STEREO_SAMPLE)
		return;

	s16 last_left = 0;
	s16 last_right = 0;
	memcpy(&last_left, destination + valid_bytes - 4, sizeof(s16));
	memcpy(&last_right, destination + valid_bytes - 2, sizeof(s16));

	s16 *out = (s16 *)(destination + valid_bytes);
	const u32 missing_samples = missing_bytes / BYTES_PER_STEREO_SAMPLE;
	const u32 fade_samples = MinimumU32(missing_samples, UNDERFLOW_FADE_SAMPLES);

	for (u32 i = 0; i < fade_samples; ++i)
	{
		const s32 scale = (s32)(UNDERFLOW_FADE_SAMPLES - i);
		out[i * 2] = (s16)(((s32)last_left * scale) / (s32)UNDERFLOW_FADE_SAMPLES);
		out[i * 2 + 1] = (s16)(((s32)last_right * scale) / (s32)UNDERFLOW_FADE_SAMPLES);
	}
}

static void FillNextDMABuffer()
{
	const u8 next_buffer = dma_buffer_index ^ 1;
	u8 *destination = dma_buffers[next_buffer];

	LWP_MutexLock(audiomutex);

	const u32 available_bytes = MinimumU32(fifo_queued_bytes, dma_block_bytes);
	CopyFromFifoUnlocked(destination, available_bytes);

	if (available_bytes < dma_block_bytes)
	{
		++stat_underruns;
		FadeMissingAudio(destination, available_bytes, dma_block_bytes);
	}

	stat_consumed_samples += available_bytes / BYTES_PER_STEREO_SAMPLE;
	++stat_dma_blocks;
	RecordQueueDepthUnlocked();

	dma_buffer_index = next_buffer;

	LWP_MutexUnlock(audiomutex);
}

static void *audio_thread(void *)
{
	while (!audio_thread_abort)
	{
		// Generate only the amount required to restore the target queue depth.
		SPU_Emulate_user();

		if (audio_thread_abort)
			break;

		FillNextDMABuffer();
		LWP_ThreadSleep(audioqueue);
	}

	return NULL;
}

static void MixAudio()
{
	DCFlushRange(dma_buffers[dma_buffer_index], dma_block_bytes);
	AUDIO_InitDMA((u32)dma_buffers[dma_buffer_index], dma_block_bytes);
	LWP_ThreadSignal(audioqueue);
}

int SNDOGCInit(int buffersize)
{
	dma_buffer_index = 0;
	dma_block_bytes = (u32)buffersize;
	fifo_capacity_bytes = dma_block_bytes * FIFO_BLOCK_COUNT;
	fifo_target_bytes = dma_block_bytes * FIFO_TARGET_BLOCKS;
	fifo_read_pos = 0;
	fifo_write_pos = 0;
	fifo_queued_bytes = 0;

	if (!asnd_initialized)
	{
		ASND_Init();
		asnd_initialized = true;
	}

	dma_buffers[0] = (u8 *)memalign(32, dma_block_bytes);
	dma_buffers[1] = (u8 *)memalign(32, dma_block_bytes);
	audio_fifo = (u8 *)memalign(32, fifo_capacity_bytes);

	if (!dma_buffers[0] || !dma_buffers[1] || !audio_fifo)
	{
		if (dma_buffers[0]) free(dma_buffers[0]);
		if (dma_buffers[1]) free(dma_buffers[1]);
		if (audio_fifo) free(audio_fifo);
		dma_buffers[0] = dma_buffers[1] = NULL;
		audio_fifo = NULL;
		return -1;
	}

	memset(dma_buffers[0], 0, dma_block_bytes);
	memset(dma_buffers[1], 0, dma_block_bytes);
	memset(audio_fifo, 0, fifo_capacity_bytes);
	DCFlushRange(dma_buffers[0], dma_block_bytes);
	DCFlushRange(dma_buffers[1], dma_block_bytes);

	if (audiomutex == LWP_MUTEX_NULL)
		LWP_MutexInit(&audiomutex, false);

	if (audioqueue == LWP_TQUEUE_NULL)
		LWP_InitQueue(&audioqueue);

	ResetStatisticsUnlocked();

	AUDIO_InitDMA((u32)dma_buffers[dma_buffer_index], dma_block_bytes);
	AUDIO_StartDMA();

	audio_thread_abort = false;
	if (audiothread == LWP_THREAD_NULL)
		LWP_CreateThread(&audiothread, audio_thread, NULL, NULL, 0, 67);

	SNDOGCUnMuteAudio();
	return 0;
}

void SNDOGCDeInit()
{
	SNDOGCMuteAudio();
	AUDIO_StopDMA();

	audio_thread_abort = true;
	if (audioqueue != LWP_TQUEUE_NULL)
		LWP_ThreadSignal(audioqueue);

	if (audiothread != LWP_THREAD_NULL)
	{
		LWP_JoinThread(audiothread, NULL);
		audiothread = LWP_THREAD_NULL;
	}

	if (dma_buffers[0])
	{
		free(dma_buffers[0]);
		dma_buffers[0] = NULL;
	}
	if (dma_buffers[1])
	{
		free(dma_buffers[1]);
		dma_buffers[1] = NULL;
	}
	if (audio_fifo)
	{
		free(audio_fifo);
		audio_fifo = NULL;
	}

	if (audiomutex != LWP_MUTEX_NULL)
	{
		LWP_MutexDestroy(audiomutex);
		audiomutex = LWP_MUTEX_NULL;
	}

	dma_block_bytes = 0;
	fifo_capacity_bytes = 0;
	fifo_target_bytes = 0;
	fifo_read_pos = 0;
	fifo_write_pos = 0;
	fifo_queued_bytes = 0;
	dma_buffer_index = 0;
}

void SNDOGCUpdateAudio(s16 *buffer, u32 num_samples)
{
	if (!audio_fifo || audiomutex == LWP_MUTEX_NULL || num_samples == 0)
		return;

	const u32 requested_bytes = num_samples * BYTES_PER_STEREO_SAMPLE;

	LWP_MutexLock(audiomutex);

	const u32 free_bytes = fifo_capacity_bytes - fifo_queued_bytes;
	const u32 accepted_bytes = MinimumU32(requested_bytes, free_bytes);

	CopyIntoFifoUnlocked((const u8 *)buffer, accepted_bytes);
	stat_produced_samples += accepted_bytes / BYTES_PER_STEREO_SAMPLE;

	if (accepted_bytes < requested_bytes)
		++stat_overflows;

	RecordQueueDepthUnlocked();
	LWP_MutexUnlock(audiomutex);
}

u32 SNDOGCGetAudioSpace()
{
	if (!audio_fifo || audiomutex == LWP_MUTEX_NULL)
		return 0;

	LWP_MutexLock(audiomutex);

	u32 wanted_bytes = 0;
	if (fifo_queued_bytes < fifo_target_bytes)
		wanted_bytes = fifo_target_bytes - fifo_queued_bytes;

	const u32 free_bytes = fifo_capacity_bytes - fifo_queued_bytes;
	wanted_bytes = MinimumU32(wanted_bytes, free_bytes);

	LWP_MutexUnlock(audiomutex);
	return wanted_bytes / BYTES_PER_STEREO_SAMPLE;
}

void SNDOGCClearBuffer()
{
	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexLock(audiomutex);

	fifo_read_pos = 0;
	fifo_write_pos = 0;
	fifo_queued_bytes = 0;
	dma_buffer_index = 0;

	if (audio_fifo)
		memset(audio_fifo, 0, fifo_capacity_bytes);

	if (dma_buffers[0])
	{
		memset(dma_buffers[0], 0, dma_block_bytes);
		DCFlushRange(dma_buffers[0], dma_block_bytes);
	}
	if (dma_buffers[1])
	{
		memset(dma_buffers[1], 0, dma_block_bytes);
		DCFlushRange(dma_buffers[1], dma_block_bytes);
	}

	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexUnlock(audiomutex);
}

void SNDOGCMuteAudio()
{
	AUDIO_RegisterDMACallback(NULL);
	AUDIO_StopDMA();
	SNDOGCClearBuffer();
}

void SNDOGCUnMuteAudio()
{
	SNDOGCClearBuffer();
	AUDIO_RegisterDMACallback(MixAudio);

	// Begin with a silent block while the worker prepares the next one.
	DCFlushRange(dma_buffers[dma_buffer_index], dma_block_bytes);
	AUDIO_InitDMA((u32)dma_buffers[dma_buffer_index], dma_block_bytes);
	LWP_ThreadSignal(audioqueue);
	AUDIO_StartDMA();
}

void SNDOGCSetVolume(int volume)
{
	if (volume < 0) volume = 0;
	if (volume > 255) volume = 255;

	sndogcvolume = volume;
	ASND_ChangeVolumeVoice(0, sndogcvolume, sndogcvolume);
}

void SNDOGCResetStats()
{
	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexLock(audiomutex);

	ResetStatisticsUnlocked();
	RecordQueueDepthUnlocked();

	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexUnlock(audiomutex);
}

void SNDOGCGetStats(SNDOGCStats *stats)
{
	if (!stats)
		return;

	memset(stats, 0, sizeof(*stats));

	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexLock(audiomutex);

	stats->queued_samples = fifo_queued_bytes / BYTES_PER_STEREO_SAMPLE;
	stats->target_samples = fifo_target_bytes / BYTES_PER_STEREO_SAMPLE;
	stats->capacity_samples = fifo_capacity_bytes / BYTES_PER_STEREO_SAMPLE;
	stats->minimum_samples =
		(stat_minimum_bytes == 0xFFFFFFFFu) ? 0 :
		(stat_minimum_bytes / BYTES_PER_STEREO_SAMPLE);
	stats->maximum_samples = stat_maximum_bytes / BYTES_PER_STEREO_SAMPLE;
	stats->underruns = stat_underruns;
	stats->overflows = stat_overflows;
	stats->dma_blocks = stat_dma_blocks;
	stats->produced_samples = stat_produced_samples;
	stats->consumed_samples = stat_consumed_samples;

	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexUnlock(audiomutex);
}
