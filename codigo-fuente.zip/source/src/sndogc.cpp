/*  Copyright 2005-2006 Theo Berkau
    Copyright (C) 2012 DeSmuMEWii team

    This file is part of DeSmuMEWii

    DeSmuMEWii is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    DeSmuMEWii is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with DeSmuMEWii; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <gccore.h>
#include <gctypes.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#include "types.h"
#include "SPU.h"
#include "sndogc.h"
#include "debug.h"
#include <unistd.h>
#include <ogc/lwp_watchdog.h>

#define NEW_SOUND_SYSTEM


#ifdef NEW_SOUND_SYSTEM
#include <asndlib.h>
#endif



int SNDOGCInit(int buffersize);
void SNDOGCDeInit();
void SNDOGCUpdateAudio(s16 *buffer, u32 num_samples);
u32 SNDOGCGetAudioSpace();
void SNDOGCMuteAudio();
void SNDOGCUnMuteAudio();
void SNDOGCSetVolume(int volume);
void SNDOGCClearBuffer();

SoundInterface_struct SNDOGC = {
	SNDCORE_OGC,
	"OGC Sound Interface",
	SNDOGCInit,
	SNDOGCDeInit,
	SNDOGCUpdateAudio,
	SNDOGCGetAudioSpace,
	SNDOGCMuteAudio,
	SNDOGCUnMuteAudio,
	SNDOGCSetVolume,
	SNDOGCClearBuffer
};

static u8 *stereodata16[2] = {NULL, NULL};
static u8 *tmpbuffer = NULL;
static u8 whichab;
static u32 soundpos;
static u32 soundoffset;
static u32 soundbufsize;
static lwpq_t audioqueue = LWP_TQUEUE_NULL;
static lwp_t audiothread = LWP_THREAD_NULL;
static mutex_t audiomutex = LWP_MUTEX_NULL;
static volatile bool audio_thread_abort = false;
static bool asnd_initialized = false;
static int sndogcvolume = 100;

// Audio diagnostic state. These counters do not change playback decisions.
static u64 diag_produced_samples = 0;
static u64 diag_requested_output_samples = 0;
static u64 diag_real_output_samples = 0;
static u64 diag_missing_samples = 0;
static u64 diag_overflow_samples = 0;
static u64 diag_mix_ticks_total = 0;
static u64 diag_mix_ticks_max = 0;
static u32 diag_update_calls = 0;
static volatile u32 diag_dma_callbacks = 0;
static u32 diag_audio_thread_loops = 0;
static u32 diag_underrun_events = 0;
static u32 diag_overflow_events = 0;
static u32 diag_zero_space_calls = 0;
static u32 diag_space_calls = 0;
static u32 diag_mix_timing_samples = 0;
static u32 diag_buffered_bytes = 0;
static u32 diag_min_fill_bytes = 0;
static u32 diag_max_fill_bytes = 0;
static u32 diag_min_free_samples = 0;
static u32 diag_max_free_samples = 0;

static void UpdateFillExtremes()
{
	if (diag_buffered_bytes < diag_min_fill_bytes)
		diag_min_fill_bytes = diag_buffered_bytes;
	if (diag_buffered_bytes > diag_max_fill_bytes)
		diag_max_fill_bytes = diag_buffered_bytes;
}

static void *audio_thread(void*)
{
	u8 *sdata, *soundbuf;
	u32 timing_counter = 0;

	while (!audio_thread_abort)
	{
		// Sample one of every eight calls to avoid making the diagnostic itself
		// a significant audio cost.
		if ((timing_counter++ & 7) == 0)
		{
			const u64 mix_start = gettime();
			SPU_Emulate_user();
			const u64 mix_ticks = gettime() - mix_start;

			if (audiomutex != LWP_MUTEX_NULL)
				LWP_MutexLock(audiomutex);
			diag_mix_ticks_total += mix_ticks;
			if (mix_ticks > diag_mix_ticks_max)
				diag_mix_ticks_max = mix_ticks;
			++diag_mix_timing_samples;
			if (audiomutex != LWP_MUTEX_NULL)
				LWP_MutexUnlock(audiomutex);
		}
		else
		{
			SPU_Emulate_user();
		}

		usleep(10);

		if (audio_thread_abort)
			break;

		LWP_MutexLock(audiomutex);

		if (audio_thread_abort)
		{
			LWP_MutexUnlock(audiomutex);
			break;
		}

		++diag_audio_thread_loops;

		const u32 requested_bytes = soundbufsize;
		const u32 real_bytes =
			(diag_buffered_bytes < requested_bytes) ? diag_buffered_bytes : requested_bytes;
		const u32 missing_bytes = requested_bytes - real_bytes;

		diag_requested_output_samples += requested_bytes / (sizeof(s16) * 2);
		diag_real_output_samples += real_bytes / (sizeof(s16) * 2);

		if (missing_bytes > 0)
		{
			++diag_underrun_events;
			diag_missing_samples += missing_bytes / (sizeof(s16) * 2);
		}

		diag_buffered_bytes -= real_bytes;
		UpdateFillExtremes();

		whichab ^= 1;
		sdata = (u8*)stereodata16[whichab];
		soundbuf = (u8*)tmpbuffer;

		for (u32 i = 0; i < soundbufsize; i++)
		{
			if (soundpos >= soundbufsize)
				soundpos = 0;

			sdata[i] = soundbuf[soundpos];
			soundpos++;
		}

		LWP_MutexUnlock(audiomutex);
		LWP_ThreadSleep(audioqueue);
	}

	return NULL;
}

//////////////////////////////////////////////////////////////////////////////

static void MixAudio()
{
	++diag_dma_callbacks;

#ifdef NEW_SOUND_SYSTEM
	DCFlushRange(stereodata16[whichab], soundbufsize);
	AUDIO_InitDMA((u32) stereodata16[whichab], soundbufsize);
#else
	AUDIO_StopDMA();
	DCFlushRange(stereodata16[whichab], soundbufsize);
	AUDIO_InitDMA((u32) stereodata16[whichab], soundbufsize);
	AUDIO_StartDMA();
#endif

	LWP_ThreadSignal(audioqueue);
}

//////////////////////////////////////////////////////////////////////////////

int SNDOGCInit(int buffersize)
{
	whichab = 0;

#ifdef NEW_SOUND_SYSTEM
	// ASND belongs to the whole application, not to one loaded ROM.
	// Initializing it repeatedly can leave the second audio session blocked.
	if (!asnd_initialized)
	{
		ASND_Init();
		asnd_initialized = true;
	}
#else
	AUDIO_Init(NULL);
	AUDIO_SetDSPSampleRate(AI_SAMPLERATE_48KHZ);
	AUDIO_SetStreamSampleRate(AI_SAMPLERATE_48KHZ);
	AUDIO_SetStreamVolLeft(sndogcvolume);
	AUDIO_SetStreamVolRight(sndogcvolume);
#endif
	

	soundoffset = 0;
	soundbufsize = buffersize;
	soundpos = 0;

	if ((stereodata16[0] = (u8 *)memalign(32, soundbufsize)) == NULL ||
	    (stereodata16[1] = (u8 *)memalign(32, soundbufsize)) == NULL ||
		(tmpbuffer       = (u8 *)malloc(soundbufsize)) == NULL)
		return -1;

	memset(stereodata16[0], 0, soundbufsize);
	memset(stereodata16[1], 0, soundbufsize);
	memset(tmpbuffer,       0, soundbufsize);

	diag_buffered_bytes = 0;
	SNDOGCResetDiagnostics();

#ifdef NEW_SOUND_SYSTEM

	DCFlushRange(stereodata16[0], soundbufsize);
	DCFlushRange(stereodata16[1], soundbufsize);
	AUDIO_InitDMA((u32)stereodata16[whichab],soundbufsize);
	AUDIO_StartDMA();
#endif

	if (audiomutex == LWP_MUTEX_NULL)
		LWP_MutexInit(&audiomutex, false);

	if (audioqueue == LWP_TQUEUE_NULL)
		LWP_InitQueue(&audioqueue);
	
	audio_thread_abort = false;
	if (audiothread == LWP_THREAD_NULL)
		LWP_CreateThread(&audiothread, audio_thread, NULL, NULL, 0, 67);

	SNDOGCUnMuteAudio();

	return 0;
}

//////////////////////////////////////////////////////////////////////////////

void SNDOGCDeInit()
{
	// Stop callbacks first, then wake and join the worker before SPU_user is
	// deleted by SPU_DeInit(). The old code left this thread alive while
	// destroying its mutex and buffers, which broke the next ROM launch.
	SNDOGCMuteAudio();
	AUDIO_StopDMA();

	audio_thread_abort = true;
	if (audioqueue != LWP_TQUEUE_NULL)
		LWP_ThreadSignal(audioqueue);

	if (audiothread != LWP_THREAD_NULL)
	{
		LWP_JoinThread(audiothread, NULL);
		audiothread = LWP_THREAD_NULL;
	}

	if (stereodata16[0])
	{
		free(stereodata16[0]);
		stereodata16[0] = NULL;
	}
	if (stereodata16[1])
	{
		free(stereodata16[1]);
		stereodata16[1] = NULL;
	}
	if (tmpbuffer)
	{
		free(tmpbuffer);
		tmpbuffer = NULL;
	}

	if (audiomutex != LWP_MUTEX_NULL)
	{
		LWP_MutexDestroy(audiomutex);
		audiomutex = LWP_MUTEX_NULL;
	}

	soundbufsize = 0;
	soundpos = 0;
	soundoffset = 0;
	whichab = 0;
	diag_buffered_bytes = 0;
}

//////////////////////////////////////////////////////////////////////////////

void SNDOGCUpdateAudio(s16 *buffer, u32 num_samples)
{
	u32 copy1size = 0, copy2size = 0;
	LWP_MutexLock(audiomutex);

	const u32 produced_bytes = num_samples * sizeof(s16) * 2;
	++diag_update_calls;
	diag_produced_samples += num_samples;

	if (diag_buffered_bytes + produced_bytes > soundbufsize)
	{
		++diag_overflow_events;
		diag_overflow_samples +=
			(diag_buffered_bytes + produced_bytes - soundbufsize) / (sizeof(s16) * 2);
		diag_buffered_bytes = soundbufsize;
	}
	else
	{
		diag_buffered_bytes += produced_bytes;
	}
	UpdateFillExtremes();

	if ((soundbufsize - soundoffset) < (num_samples * sizeof(s16) * 2))
	{
		copy1size = (soundbufsize - soundoffset);
		copy2size = (num_samples * sizeof(s16) * 2) - copy1size;
	}
	else
	{
		copy1size = (num_samples * sizeof(s16) * 2);
		copy2size = 0;
	}

	memcpy((((u8 *)tmpbuffer)+soundoffset), buffer, copy1size);

	if (copy2size)
		memcpy(tmpbuffer, ((u8 *) buffer) + copy1size, copy2size);

	soundoffset += copy1size + copy2size;
	soundoffset %= soundbufsize;

	LWP_MutexUnlock(audiomutex);
}

//////////////////////////////////////////////////////////////////////////////

u32 SNDOGCGetAudioSpace()
{
	u32 freespace = 0;

	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexLock(audiomutex);

	if (soundoffset > soundpos)
		freespace = soundbufsize - soundoffset + soundpos;
	else
		freespace = soundpos - soundoffset;

	const u32 free_samples = freespace / sizeof(s16) / 2;
	++diag_space_calls;
	if (free_samples == 0)
		++diag_zero_space_calls;

	if (diag_space_calls == 1 || free_samples < diag_min_free_samples)
		diag_min_free_samples = free_samples;
	if (free_samples > diag_max_free_samples)
		diag_max_free_samples = free_samples;

	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexUnlock(audiomutex);

	return free_samples;
}

//////////////////////////////////////////////////////////////////////////////

void SNDOGCClearBuffer()
{
	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexLock(audiomutex);

	soundpos = 0;
	soundoffset = 0;
	whichab = 0;
	diag_buffered_bytes = 0;
	UpdateFillExtremes();

	if (tmpbuffer)
		memset(tmpbuffer, 0, soundbufsize);
	if (stereodata16[0])
	{
		memset(stereodata16[0], 0, soundbufsize);
		DCFlushRange(stereodata16[0], soundbufsize);
	}
	if (stereodata16[1])
	{
		memset(stereodata16[1], 0, soundbufsize);
		DCFlushRange(stereodata16[1], soundbufsize);
	}

	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexUnlock(audiomutex);
}

//////////////////////////////////////////////////////////////////////////////

void SNDOGCMuteAudio()
{
	AUDIO_RegisterDMACallback(NULL);
	AUDIO_StopDMA();
	SNDOGCClearBuffer();
}

//////////////////////////////////////////////////////////////////////////////

void SNDOGCUnMuteAudio()
{
	SNDOGCClearBuffer();
	AUDIO_RegisterDMACallback(MixAudio);
	MixAudio();
	AUDIO_StartDMA();
}

//////////////////////////////////////////////////////////////////////////////

void SNDOGCResetDiagnostics()
{
	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexLock(audiomutex);

	diag_produced_samples = 0;
	diag_requested_output_samples = 0;
	diag_real_output_samples = 0;
	diag_missing_samples = 0;
	diag_overflow_samples = 0;
	diag_mix_ticks_total = 0;
	diag_mix_ticks_max = 0;
	diag_update_calls = 0;
	diag_dma_callbacks = 0;
	diag_audio_thread_loops = 0;
	diag_underrun_events = 0;
	diag_overflow_events = 0;
	diag_zero_space_calls = 0;
	diag_space_calls = 0;
	diag_mix_timing_samples = 0;
	diag_min_fill_bytes = diag_buffered_bytes;
	diag_max_fill_bytes = diag_buffered_bytes;
	diag_min_free_samples = 0;
	diag_max_free_samples = 0;

	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexUnlock(audiomutex);
}

void SNDOGCGetDiagnostics(SNDOGCDiagnosticSnapshot *snapshot)
{
	if (!snapshot)
		return;

	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexLock(audiomutex);

	snapshot->produced_samples = diag_produced_samples;
	snapshot->requested_output_samples = diag_requested_output_samples;
	snapshot->real_output_samples = diag_real_output_samples;
	snapshot->missing_samples = diag_missing_samples;
	snapshot->overflow_samples = diag_overflow_samples;
	snapshot->mix_ticks_total = diag_mix_ticks_total;
	snapshot->mix_ticks_max = diag_mix_ticks_max;
	snapshot->update_calls = diag_update_calls;
	snapshot->dma_callbacks = diag_dma_callbacks;
	snapshot->audio_thread_loops = diag_audio_thread_loops;
	snapshot->underrun_events = diag_underrun_events;
	snapshot->overflow_events = diag_overflow_events;
	snapshot->zero_space_calls = diag_zero_space_calls;
	snapshot->space_calls = diag_space_calls;
	snapshot->mix_timing_samples = diag_mix_timing_samples;
	snapshot->current_fill_samples = diag_buffered_bytes / (sizeof(s16) * 2);
	snapshot->min_fill_samples = diag_min_fill_bytes / (sizeof(s16) * 2);
	snapshot->max_fill_samples = diag_max_fill_bytes / (sizeof(s16) * 2);
	snapshot->capacity_samples = soundbufsize / (sizeof(s16) * 2);
	snapshot->min_free_samples = diag_min_free_samples;
	snapshot->max_free_samples = diag_max_free_samples;

	if (audiomutex != LWP_MUTEX_NULL)
		LWP_MutexUnlock(audiomutex);
}

//////////////////////////////////////////////////////////////////////////////

void SNDOGCSetVolume(int volume)
{
	volume < 0 ? volume = 0 : volume > 255 ? volume = 255 : 0;
	
	sndogcvolume = volume;
	
#ifdef NEW_SOUND_SYSTEM

	// TODO: The closest I found was: 
	// ASND_ChangeVolumeVoice(s32 voice, s32 volume_l, s32 volume_r)

	ASND_ChangeVolumeVoice(0, sndogcvolume, sndogcvolume);
#else

	AUDIO_SetStreamVolLeft(sndogcvolume);
	AUDIO_SetStreamVolRight(sndogcvolume);

#endif
}

//////////////////////////////////////////////////////////////////////////////
