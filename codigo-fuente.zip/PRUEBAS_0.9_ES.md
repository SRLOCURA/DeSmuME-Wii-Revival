# Pruebas 0.9 — etapas 3D de bajo impacto

Objetivo: medir una sola vez por cuadro perfilado cuánto cuesta preparar las listas 3D y cuánto cuesta el renderizador final Soft o GX.

## Pruebas
- Yoshi’s Island DS — Soft y GX
- Mario Kart DS — Soft y GX
- Frameskip 0
- Diagnóstico Completo
- Reiniciar medición, jugar 20 segundos y abrir HOME

Fotografiar especialmente:
- FPS / Total / Núcleo DS
- GXFIFO
- 3D preparar / Render
- Polígonos / Vértices

El perfilador añade solo dos pares de lecturas de reloj por cuadro muestreado: uno alrededor de la preparación 3D y otro alrededor del render final.
