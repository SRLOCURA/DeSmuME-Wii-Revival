# DeSmuME Wii Revival

Revival experimental del port de DeSmuME para Nintendo Wii.

## Estado actual: 0.2, fuente sin compilación confirmada

Esta etapa no promete todavía una mejora de rendimiento. Su propósito es crear una base moderna que pueda compilarse, lanzarse desde WiiFlow y manejarse sin Nunchuk.

### Cambios preparados

- Eliminación de las dependencias antiguas `dopmii` y `wiikeyboard`.
- Eliminación del controlador USB2 específico de cIOS y de `mload`.
- Montaje de SD/USB mediante `fatInitDefault()` de libfat/libogc.
- Lanzamiento directo de archivos `.nds` enviados como argumento.
- Normalización de rutas `usb1:/...` y `usb2:/...` a `usb:/...`.
- Elección de renderizador mediante `--renderer=soft` o `--renderer=gx`.
- Perfil completo para Wii Remote sin Nunchuk.
- Hotkeys del emulador movidos a combinaciones para no interferir con el juego.
- Flujo de compilación preparado para GitHub Actions usando la imagen oficial de devkitPPC.

## Importante

No copies esta carpeta a la Wii esperando un ejecutable nuevo. Hasta que el flujo de compilación produzca `boot.dol`, este paquete es únicamente código fuente experimental.

## Créditos y licencia

Basado en DeSmuME Wii y DeSmuME. Se conservan los créditos originales y la licencia GPL-2.0.
