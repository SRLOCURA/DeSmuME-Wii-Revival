# DeSmuME Wii Revival

Revival experimental del port de DeSmuME para Nintendo Wii.

## Estado actual: 0.3-test

La base ya compila con devkitPPC moderno y fue comprobada en una Wii real:

- Arranca desde Homebrew Channel.
- Monta SD y abre el explorador de ROMs.
- Carga juegos con los renderizadores Soft y GX.
- Conserva partidas normales.
- Funciona con Wii Remote sin Nunchuk.

## Objetivo de esta compilación

Esta versión agrega tres piezas de infraestructura antes de comenzar optimizaciones profundas:

1. Menú inicial de texto ampliado.
2. Menú de pausa dentro del juego mediante HOME.
3. Diagnóstico desactivable para medir rendimiento sin escribir continuamente en la SD.

## Menú inicial

Permite elegir:

- SD o USB.
- Renderizador Soft o GX.
- Diagnóstico desactivado, básico o completo.
- Frameskip de 0 a 5.
- Explorador de juegos.

## Diagnóstico

- Desactivado: no toma mediciones.
- Básico: cuenta cuadros emulados, cuadros dibujados y velocidad estimada.
- Completo: además mide tiempo del núcleo de emulación y copia de video.

Las cifras se acumulan en RAM y se consultan al abrir el menú de pausa. No se escribe en la SD durante el juego.

## Lanzamiento directo desde WiiFlow

Argumentos reconocidos:

- `--renderer=soft`
- `--renderer=gx`
- `--diagnostic=off`
- `--diagnostic=basic`
- `--diagnostic=full`
- `--frameskip=0` hasta `--frameskip=5`

## Alcance de esta prueba

Todavía no incluye:

- Interfaz gráfica nueva.
- Guardar/cargar estados desde el menú.
- Cambio de renderizador durante una partida.
- Configuración persistente en archivo.
- Optimizaciones del núcleo ARM o del renderizador GX.

## Créditos y licencia

Basado en DeSmuME Wii y DeSmuME. Se conservan los créditos originales y la licencia GPL-2.0.
