# DeSmuME Wii Revival 0.21-test — caché de despacho

La fuente ya decodifica ARM y Thumb mediante tablas directas, por lo que esta
caché no tiene una ganancia garantizada. La prueba busca saber si la localidad
de los bucles repetidos de Pokémon y Yoshi compensa las comparaciones extra.

Seguridad:
- cachés separadas por CPU y modo;
- dirección y opcode exactos;
- reinicio lógico al reset/cambio de ROM;
- sin alterar ciclos emulados.

Comparar directamente con 0.20. Si empata o empeora, no se acumula en 0.22.
