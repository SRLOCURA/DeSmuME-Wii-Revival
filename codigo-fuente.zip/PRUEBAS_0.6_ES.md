# DeSmuME Wii Revival 0.6-test

- Corrige el bloqueo observado tras `Using CFlash directory:` durante lanzamiento directo.
- Usa Slot-2 desactivado por defecto para juegos comerciales.
- Acepta rutas WiiFlow completas, entre comillas y con formato `rompath = ...`.
- Mantiene compatibilidad con argumentos separados de carpeta y nombre.
