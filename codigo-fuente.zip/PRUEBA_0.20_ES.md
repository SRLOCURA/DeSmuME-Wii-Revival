# DeSmuME Wii Revival 0.20-test — LTO global

La 0.19 rindió aproximadamente igual que la 0.18. Por disciplina, esas
lecturas de datos adicionales no se acumulan todavía.

Esta prueba vuelve a 0.18 y activa optimización entre archivos con LTO.
El objetivo es una mejora general en ARM9, ARM7, MMU, GPU 2D y SPU sin cambiar
el comportamiento del emulador.

Los contadores ARM9/ARM7, Timers y Math deberían seguir siendo prácticamente
iguales: representan trabajo emulado. Lo que debe bajar es el tiempo del
núcleo DS y el tiempo total del host Wii.
