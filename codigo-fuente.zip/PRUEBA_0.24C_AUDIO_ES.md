# DeSmuME Wii Revival 0.24C-test — interpolación de audio

## Resultado anterior

El headroom redujo de forma clara el ruido parecido a bocinas rotas, aunque
el contador de clipping no mostró una reducción decisiva. Esto apunta a una
distorsión sensible a amplitud, pero no necesariamente a clamp s16 clásico.

## Modos de interpolación

- Ninguna: muestra más cercana; menor costo y más aspereza potencial.
- Lineal: modo original predeterminado.
- Coseno LUT: transición más suave entre muestras, sin ejecutar cos() en cada
  muestra.

## Prueba recomendada

Mantener fijo el perfil de headroom que haya sonado mejor y cambiar únicamente
la interpolación. Comparar la misma música y los mismos efectos.

Observar:
- ruido tipo bocina rota;
- claridad de agudos;
- volumen;
- tono;
- FPS y Núcleo DS;
- Under/Over.

Si Coseno LUT limpia el audio con costo aceptable, será la base. Si Lineal
sigue igual y Ninguna empeora, la interpolación participa en el problema pero
no lo resuelve por completo. Si los tres suenan iguales, la siguiente etapa
será temporización y avance fraccional de canales.
