# Controles previstos en DeSmuME Wii Revival 0.2

## Wii Remote sin Nunchuk

### Capa normal

- Cruceta: cruceta de Nintendo DS
- 2: A
- 1: B
- +: Start
- -: Select
- B: tocar la pantalla con el puntero IR
- HOME: salir del emulador

### Capa secundaria: mantener A

- A + 1: L
- A + 2: R
- A + +: X
- A + -: Y
- A + B: mostrar u ocultar consola
- A + Arriba: cambiar disposición de pantallas
- A + Abajo: mostrar u ocultar cursor
- A + Derecha: aumentar frameskip
- A + Izquierda: reducir frameskip

## Nunchuk

- Stick: cruceta de Nintendo DS
- C: A
- Z: B
- 1: X
- 2: Y
- +: Start
- -: Select
- A: tocar pantalla con el puntero

## Classic Controller

Se mantiene el mapeo natural de A, B, X, Y, L, R, cruceta, Start y Select.

Hotkeys: mantener ZL y usar A o la cruceta.

## Control de GameCube

Se conserva el mapeo de botones y stick del código original.

Hotkeys: mantener Z y usar A o la cruceta.
