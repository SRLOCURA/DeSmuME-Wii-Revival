# Controles de DeSmuME Wii Revival 0.3-test

## Wii Remote sin Nunchuk

### Capa normal

- Cruceta: cruceta de Nintendo DS
- 2: A
- 1: B
- +: Start
- -: Select
- B: tocar la pantalla con el puntero IR
- HOME: abrir el menú de pausa

### Capa secundaria: mantener A

- A + 1: L
- A + 2: R
- A + +: X
- A + -: Y
- A + Arriba: cambiar disposición de pantallas
- A + Abajo: mostrar u ocultar cursor
- A + Derecha: aumentar frameskip
- A + Izquierda: reducir frameskip

## Menú de pausa

- Cruceta arriba/abajo: mover selección
- Cruceta izquierda/derecha: cambiar una opción
- A: aceptar o cambiar la opción seleccionada
- B o HOME: continuar la partida

Opciones incluidas en esta prueba:

- Continuar
- Frameskip 0 a 5
- Disposición de pantallas
- Cursor táctil visible u oculto
- Diagnóstico desactivado, básico o completo
- Reiniciar juego
- Salir del emulador

## Nunchuk

- Stick: cruceta de Nintendo DS
- C: A
- Z: B
- 1: X
- 2: Y
- +: Start
- -: Select
- A: tocar pantalla con el puntero
- HOME: abrir el menú de pausa

## Classic Controller

Se conserva el mapeo natural de A, B, X, Y, L, R, cruceta, Start y Select.
HOME abre el menú de pausa.

## Control de GameCube

Se conserva el mapeo de botones y stick del código original.
La combinación Z + L + R abre el menú de pausa.
