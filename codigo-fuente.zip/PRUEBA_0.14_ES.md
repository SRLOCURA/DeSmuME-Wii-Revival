# DeSmuME Wii Revival 0.14-test

Esta compilación conserva exactamente la corrección gráfica de GX de 0.13.
No intenta cambiar el renderizado.

Añade contadores de:
- modos de polígono: modulación, decal, toon/highlight y shadow;
- polígonos con/sin textura;
- polígonos translúcidos y wireframe;
- depth-equal y escritura de profundidad alfa;
- fog, edge marking, W-buffer, alpha test y alpha blending.

El objetivo es comparar tres momentos de Mario Kart DS:
1. animación de recorrido de pista que se ve corrupta;
2. instante del conteo 3-2-1 que no aparece;
3. carrera normal que ya se ve correctamente.
